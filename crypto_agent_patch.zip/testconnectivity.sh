#!/bin/bash
# ==============================================================================
# Crypto Bug Hunter — API Connectivity Test
# Tests all API keys and services, saves result to apikey_log/
# ==============================================================================

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BASE_DIR"

LOG_DIR="apikey_log"
mkdir -p "$LOG_DIR"

TIMESTAMP=$(date "+%Y%m%d_%H%M%S")
LOG_FILE="$LOG_DIR/connectivity_$TIMESTAMP.log"
NOW=$(date "+%Y-%m-%d %H:%M:%S")

PASSED=0
FAILED=0
SKIPPED=0
TOTAL=0
RESULTS=()

log() {
    echo "$1" >> "$LOG_FILE"
}

log_line() {
    log "--------------------------------------------------------------------------------"
}

print_and_log() {
    echo -e "$1"
    log "$(echo -e "$1" | sed 's/\x1b\[[0-9;]*m//g')"
}

test_service() {
    local name="$1"
    local url="$2"
    local method="${3:-GET}"
    local auth_header="$4"
    local timeout="${5:-10}"
    local extra_curl="${6:-}"

    TOTAL=$((TOTAL + 1))

    if [ "$method" = "GET" ]; then
        if [ -n "$auth_header" ]; then
            RESP=$(curl -s -o /dev/null -w "HTTP_CODE:%{http_code}" --max-time "$timeout" -H "$auth_header" "$url" 2>&1)
        else
            RESP=$(curl -s -o /dev/null -w "HTTP_CODE:%{http_code}" --max-time "$timeout" "$url" 2>&1)
        fi
    elif [ "$method" = "POST" ]; then
        RESP=$(curl -s -o /dev/null -w "HTTP_CODE:%{http_code}" --max-time "$timeout" -X POST -H "$auth_header" "$extra_curl" "$url" 2>&1)
    fi

    HTTP_CODE=$(echo "$RESP" | grep -oP 'HTTP_CODE:\K\d+')
    if [ -z "$HTTP_CODE" ]; then
        HTTP_CODE="000"
    fi

    if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "201" ] || [ "$HTTP_CODE" = "204" ]; then
        PASSED=$((PASSED + 1))
        RESULTS+=("PASS  $name: OK ($HTTP_CODE)")
        print_and_log "  \e[32mPASS\e[0m  $name: OK ($HTTP_CODE)"
    else
        FAILED=$((FAILED + 1))
        RESULTS+=("FAIL  $name: HTTP $HTTP_CODE")
        print_and_log "  \e[31mFAIL\e[0m  $name: HTTP $HTTP_CODE"
    fi
}

# ==============================================================================
echo ""
echo "====================================================="
echo "  Crypto Bug Hunter - API Connectivity Test"
echo "  $NOW"
echo "====================================================="
echo ""

log_line
log "  API Connectivity Test"
log "  Date: $NOW"
log_line

# Source api.txt values by parsing with python if available
PYTHON=""
for cmd in python3 python; do
    if command -v $cmd &> /dev/null; then
        tmp=$($cmd --version 2>&1 | grep -oP '\d+\.\d+' | head -1)
        if [ -n "$tmp" ]; then
            MAJOR=$(echo "$tmp" | cut -d. -f1)
            MINOR=$(echo "$tmp" | cut -d. -f2)
            if [ "$MAJOR" -eq 3 ] && [ "$MINOR" -ge 8 ]; then
                PYTHON=$cmd
                break
            fi
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "ERROR: Python 3.8+ required for config parsing"
    exit 1
fi

# Check if api.txt exists — if missing, all cred tests will SKIP
if [ ! -f "api.txt" ]; then
    echo -e "\e[33mNOTE: api.txt not found — credential-dependent tests will be skipped\e[0m"
    echo ""
fi

# Use Python to extract config values (empty if api.txt missing)
ETH_KEY=$($PYTHON -c "from config import Config; c=Config(); print(c.get('ETHERSCAN_API_KEY',''))" 2>/dev/null)
OR1=$($PYTHON -c "from config import Config; c=Config(); print(c.get('OPENROUTER_API_KEY_1',''))" 2>/dev/null)
OR2=$($PYTHON -c "from config import Config; c=Config(); print(c.get('OPENROUTER_API_KEY_2',''))" 2>/dev/null)
OR3=$($PYTHON -c "from config import Config; c=Config(); print(c.get('OPENROUTER_API_KEY_3',''))" 2>/dev/null)
OR4=$($PYTHON -c "from config import Config; c=Config(); print(c.get('OPENROUTER_API_KEY_4',''))" 2>/dev/null)
NV_KEY=$($PYTHON -c "from config import Config; c=Config(); print(c.get('NVIDIA_API_KEY',''))" 2>/dev/null)
TG_KEY=$($PYTHON -c "from config import Config; c=Config(); print(c.get('TELEGRAM_BOT_TOKEN',''))" 2>/dev/null)
H1_USER=$($PYTHON -c "from config import Config; c=Config(); h=c.get_hackerone_creds(); print(h['username'] if h else '')" 2>/dev/null)
H1_TOKEN=$($PYTHON -c "from config import Config; c=Config(); h=c.get_hackerone_creds(); print(h['token'] if h else '')" 2>/dev/null)
IMM_EMAIL=$($PYTHON -c "from config import Config; c=Config(); i=c.get_immunefi_creds(); print(i['email'] if i else '')" 2>/dev/null)
IMM_PASS=$($PYTHON -c "from config import Config; c=Config(); i=c.get_immunefi_creds(); print(i['password'] if i else '')" 2>/dev/null)
MONGO_URI=$($PYTHON -c "from config import Config; c=Config(); print(c.get('MONGODB_URI',''))" 2>/dev/null)

# ---------- 1. Etherscan ----------
echo "Etherscan..."
if [ -n "$ETH_KEY" ]; then
    test_service "Etherscan" "https://api.etherscan.io/v2/api?chainid=1&module=contract&action=getsourcecode&address=0x0000000000000000000000000000000000000000&apikey=$ETH_KEY"
else
    TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
    print_and_log "  \e[31mFAIL\e[0m  Etherscan: No API key"
    RESULTS+=("FAIL  Etherscan: No API key")
fi

# ---------- 2-5. OpenRouter ×4 ----------
for i in 1 2 3 4; do
    KEY_VAR="OR$i"
    KEY="${!KEY_VAR}"
    echo "OpenRouter K$i..."
    if [ -n "$KEY" ]; then
        test_service "OpenRouter K$i" "https://openrouter.ai/api/v1/key" "GET" "Authorization: Bearer $KEY"
    else
        TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
        print_and_log "  \e[31mFAIL\e[0m  OpenRouter K$i: No key"
        RESULTS+=("FAIL  OpenRouter K$i: No key")
    fi
done

# ---------- 6. NVIDIA ----------
echo "NVIDIA..."
if [ -n "$NV_KEY" ]; then
    test_service "NVIDIA" "https://integrate.api.nvidia.com/v1/models" "GET" "Authorization: Bearer $NV_KEY"
else
    TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
    print_and_log "  \e[31mFAIL\e[0m  NVIDIA: No key"
    RESULTS+=("FAIL  NVIDIA: No key")
fi

# ---------- 7. Telegram ----------
echo "Telegram..."
if [ -n "$TG_KEY" ]; then
    test_service "Telegram" "https://api.telegram.org/bot$TG_KEY/getMe"
else
    TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
    print_and_log "  \e[31mFAIL\e[0m  Telegram: No token"
    RESULTS+=("FAIL  Telegram: No token")
fi

# ---------- 8. HackerOne ----------
echo "HackerOne..."
if [ -n "$H1_USER" ] && [ -n "$H1_TOKEN" ]; then
    TOTAL=$((TOTAL + 1))
    RESP=$(curl -s -o /dev/null -w "HTTP_CODE:%{http_code}" --max-time 10 \
        -u "$H1_USER:$H1_TOKEN" \
        -H "Accept: application/json" \
        "https://api.hackerone.com/v1/hackers/me/reports?page[size]=1" 2>&1)
    HTTP_CODE=$(echo "$RESP" | grep -oP 'HTTP_CODE:\K\d+')
    [ -z "$HTTP_CODE" ] && HTTP_CODE="000"
    if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "201" ] || [ "$HTTP_CODE" = "204" ]; then
        PASSED=$((PASSED + 1))
        print_and_log "  \e[32mPASS\e[0m  HackerOne: OK ($HTTP_CODE)"
        RESULTS+=("PASS  HackerOne: OK ($HTTP_CODE)")
    else
        FAILED=$((FAILED + 1))
        CURL_ERR=$(echo "$RESP" | grep -oP 'curl:\s*\(.*?\).*' | head -1)
        DETAIL="${CURL_ERR:-HTTP $HTTP_CODE}"
        print_and_log "  \e[31mFAIL\e[0m  HackerOne: $DETAIL"
        RESULTS+=("FAIL  HackerOne: $DETAIL")
    fi
elif [ -n "$H1_TOKEN" ] && [ -z "$H1_USER" ]; then
    TOTAL=$((TOTAL + 1)); SKIPPED=$((SKIPPED + 1))
    print_and_log "  \e[33mSKIP\e[0m  HackerOne: Has token but no API identifier (set HACKERONE_API_USERNAME)"
    RESULTS+=("SKIP  HackerOne: No API identifier")
else
    TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
    print_and_log "  \e[33mWARN\e[0m  HackerOne: No credentials"
    RESULTS+=("WARN  HackerOne: No credentials")
fi

# ---------- 9. Immunefi ----------
echo "Immunefi..."
if [ -n "$IMM_EMAIL" ] && [ -n "$IMM_PASS" ]; then
    test_service "Immunefi" "https://bugs.immunefi.com"
else
    TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
    print_and_log "  \e[33mWARN\e[0m  Immunefi: No credentials"
    RESULTS+=("WARN  Immunefi: No credentials")
fi

# ---------- 10. MongoDB ----------
echo "MongoDB..."
if [ -n "$MONGO_URI" ]; then
    if command -v mongosh &> /dev/null; then
        MONGO_RESULT=$(mongosh "$MONGO_URI" --eval "db.runCommand({ping:1})" --quiet 2>&1 | grep -c "ok")
        if [ "$MONGO_RESULT" -gt 0 ]; then
            PASSED=$((PASSED + 1))
            print_and_log "  \e[32mPASS\e[0m  MongoDB: Ping OK"
            RESULTS+=("PASS  MongoDB: Ping OK")
        else
            FAILED=$((FAILED + 1))
            print_and_log "  \e[31mFAIL\e[0m  MongoDB: Ping failed"
            RESULTS+=("FAIL  MongoDB: Ping failed")
        fi
    elif command -v $PYTHON &> /dev/null; then
        MONGO_RESULT=$($PYTHON -c "
try:
    from pymongo import MongoClient
    from pymongo.server_api import ServerApi
    c = MongoClient('$MONGO_URI', serverSelectionTimeoutMS=5000, server_api=ServerApi('1'))
    c.admin.command('ping')
    print('OK')
except Exception as e:
    print('FAIL:' + str(e)[:80])
" 2>&1)
        if echo "$MONGO_RESULT" | grep -q "OK"; then
            TOTAL=$((TOTAL - 1))
            PASSED=$((PASSED + 1))
            print_and_log "  \e[32mPASS\e[0m  MongoDB: Ping OK (pymongo)"
            RESULTS+=("PASS  MongoDB: Ping OK")
        else
            FAILED=$((FAILED + 1))
            print_and_log "  \e[31mFAIL\e[0m  MongoDB: $MONGO_RESULT"
            RESULTS+=("FAIL  MongoDB: $MONGO_RESULT")
        fi
    else
        TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
        print_and_log "  \e[31mFAIL\e[0m  MongoDB: No mongosh or pymongo"
        RESULTS+=("FAIL  MongoDB: No mongosh or pymongo")
    fi
else
    TOTAL=$((TOTAL + 1)); FAILED=$((FAILED + 1))
    print_and_log "  \e[31mFAIL\e[0m  MongoDB: No URI configured"
    RESULTS+=("FAIL  MongoDB: No URI configured")
fi

# ==============================================================================
# Write results to log file
log_line
for R in "${RESULTS[@]}"; do
    log "$R"
done
log_line
TESTED=$((TOTAL - SKIPPED))
log "  $PASSED/$TESTED services operational"
if [ "$FAILED" -gt 0 ]; then
    log "  WARNING: $FAILED service(s) failed"
fi
if [ "$SKIPPED" -gt 0 ]; then
    log "  NOTE: $SKIPPED service(s) skipped (missing credentials)"
fi
log_line
log "  Log saved: $LOG_FILE"

# ==============================================================================
echo ""
echo "====================================================="
TESTED=$((TOTAL - SKIPPED))
if [ "$FAILED" -eq 0 ] && [ "$SKIPPED" -eq 0 ]; then
    echo -e "  \e[32mAll $TESTED services operational\e[0m"
elif [ "$FAILED" -eq 0 ] && [ "$SKIPPED" -gt 0 ]; then
    echo -e "  \e[33mAll $TESTED tested OK, $SKIPPED skipped (missing creds)\e[0m"
elif [ "$FAILED" -gt 0 ]; then
    echo -e "  \e[33m$PASSED/$TESTED services operational"
    echo -e "  $FAILED service(s) failed - check credentials\e[0m"
fi
echo "====================================================="
echo "Log saved: $LOG_FILE"
echo ""

exit $([ "$FAILED" -eq 0 ] && echo 0 || echo 1)
