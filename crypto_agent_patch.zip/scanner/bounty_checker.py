import logging
import requests
import time

logger = logging.getLogger(__name__)

IMMUNEFI_API_BASE = "https://immunefi.com"
HACKERONE_API_BASE = "https://api.hackerone.com"

def check_immunefi(contract_address):
    logger.info(f"Checking Immunefi for {contract_address}")
    try:
        url = f"{IMMUNEFI_API_BASE}/api/programs"
        headers = {"User-Agent": "Mozilla/5.0 (compatible; ResearchBot/1.0)"}
        resp = requests.get(url, headers=headers, timeout=15)
        if resp.status_code == 200:
            programs = resp.json()
            for program in programs:
                scopes = program.get("scopes", [])
                for scope in scopes:
                    if contract_address.lower() in scope.get("address", "").lower():
                        logger.info(f"Found on Immunefi: {program.get('name', 'Unknown')}")
                        return True, program.get("name", "Unknown")
    except Exception as e:
        logger.warning(f"Immunefi check failed: {e}")
    return False, None

def check_hackerone(contract_address, api_username=None, api_token=None):
    logger.info(f"Checking HackerOne for {contract_address}")
    if not api_username or not api_token:
        return False, None
    try:
        auth = (api_username, api_token)
        url = f"{HACKERONE_API_BASE}/v1/hackers/programs"
        resp = requests.get(url, auth=auth, timeout=15)
        if resp.status_code != 200:
            return False, None
        programs = resp.json().get("data", [])
        for program in programs:
            pid = program.get("id")
            if not pid:
                continue
            handle = program.get("attributes", {}).get("handle", "")
            try:
                scope_resp = requests.get(
                    f"{HACKERONE_API_BASE}/v1/hackers/programs/{pid}/structured_scopes",
                    auth=auth, timeout=10,
                )
                if scope_resp.status_code != 200:
                    continue
                scopes = scope_resp.json().get("data", [])
                for scope in scopes:
                    scope_attrs = scope.get("attributes", {})
                    identifier = scope_attrs.get("asset_identifier", "")
                    if contract_address.lower() in identifier.lower():
                        logger.info(f"Found on HackerOne: {handle}")
                        return True, handle
            except Exception:
                continue
    except Exception as e:
        logger.warning(f"HackerOne check failed: {e}")
    return False, None

def check_bounty_eligibility(contract_address, hackeron_creds=None):
    on_immunefi, immunefi_name = check_immunefi(contract_address)
    time.sleep(1)
    on_hackerone, hackerone_handle = check_hackerone(
        contract_address,
        hackeron_creds.get("username") if hackeron_creds else None,
        hackeron_creds.get("token") if hackeron_creds else None,
    )
    if on_immunefi:
        return "immunefi", immunefi_name
    if on_hackerone:
        return "hackerone", hackerone_handle
    return None, None
