import logging
import re

logger = logging.getLogger(__name__)

class StaticAnalyzer:
    def __init__(self):
        self.patterns = [
            {
                "id": "unchecked_external_call",
                "name": "Unchecked External Call",
                "severity": "medium",
                "pattern": r'\.(call|delegatecall|staticcall)\s*\{[^}]*\}\s*\(',
                "check_valid": lambda match, code: not re.search(r'require\s*\(\s*' + re.escape(match.group(0)[:20]) + r'|\.call\s*\{[^}]*\}\s*\([^)]*\)\s*\.\s*success', code),
                "description": "External calls without proper return value checking may silently fail",
            },
            {
                "id": "reentrancy",
                "name": "Missing Reentrancy Guard",
                "severity": "high",
                "pattern": r'\.(call|delegatecall)\s*\{[^}]*\}\s*\([^)]*\)',
                "check_valid": lambda match, code: not re.search(r'ReentrancyGuard|nonReentrant|reentrancyGuard', code, re.IGNORECASE),
                "description": "External call without reentrancy protection could allow reentrancy attack",
            },
            {
                "id": "tx_origin",
                "name": "TX Origin Authorization",
                "severity": "medium",
                "pattern": r'tx\.origin',
                "description": "Using tx.origin for authorization is vulnerable to phishing attacks",
            },
            {
                "id": "block_timestamp",
                "name": "Block Timestamp Dependency",
                "severity": "low",
                "pattern": r'block\.timestamp|now\b',
                "description": "Using block.timestamp for critical logic; miners can influence timestamp",
            },
            {
                "id": "block_number",
                "name": "Block Number Dependency",
                "severity": "low",
                "pattern": r'block\.number',
                "description": "Block number can differ across chains; avoid for time-sensitive logic",
            },
            {
                "id": "unchecked_math",
                "name": "Unchecked Arithmetic",
                "severity": "medium",
                "pattern": r'(?:^|\n)\s*(?:for|while|do)\s*\([^)]*\)\s*\{[^}]*[+\-*/%][^}]*\}',
                "description": "Arithmetic operations without SafeMath or Solidity 0.8+ overflow checks",
            },
            {
                "id": "delegatecall",
                "name": "Delegatecall Usage",
                "severity": "high",
                "pattern": r'\.delegatecall\s*\(',
                "description": "Delegatecall can lead to state manipulation if target is untrusted",
            },
            {
                "id": "selfdestruct",
                "name": "Selfdestruct Usage",
                "severity": "high",
                "pattern": r'selfdestruct|suicide\s*\(',
                "description": "Contract can be destroyed; funds may be lost",
            },
            {
                "id": "centralized_control",
                "name": "Centralized Control Functions",
                "severity": "medium",
                "pattern": r'(onlyOwner|requiresAuth|isAuthorized|_checkOwner)\b',
                "description": "Privileged functions that can be controlled by a single account",
            },
            {
                "id": "gas_loop",
                "name": "Potential Gas Limit Issue",
                "severity": "low",
                "pattern": r'for\s*\([^)]*\)\s*\{[^}]{500,}\}',
                "description": "Large loop may exceed block gas limit",
            },
            {
                "id": "floating_pragma",
                "name": "Floating Pragma",
                "severity": "low",
                "pattern": r'pragma\s+solidity\s+\^[\d.]+',
                "description": "Using floating pragma may compile with unexpected compiler version",
            },
            {
                "id": "uninitialized_storage",
                "name": "Uninitialized Storage Variable",
                "severity": "medium",
                "pattern": r'(?:contract|library)\s+\w+\s*\{[^}]*?(?:address|uint\d*|bool|string)\s+(?:public|internal|private)?\s*\w+\s*;',
                "description": "Storage variables may be uninitialized",
            },
        ]

    def analyze(self, source_code):
        findings = []
        for pattern_def in self.patterns:
            try:
                matches = re.finditer(pattern_def["pattern"], source_code, re.MULTILINE)
                for match in matches:
                    is_valid = True
                    if "check_valid" in pattern_def:
                        is_valid = pattern_def["check_valid"](match, source_code)
                    if is_valid:
                        start = max(0, match.start() - 50)
                        end = min(len(source_code), match.end() + 50)
                        context = source_code[start:end]
                        finding = {
                            "id": pattern_def["id"],
                            "title": pattern_def["name"],
                            "severity": pattern_def["severity"],
                            "description": pattern_def["description"],
                            "line_number": source_code[:match.start()].count("\n") + 1,
                            "context": context.strip(),
                        }
                        findings.append(finding)
            except re.error as e:
                logger.warning(f"Regex error for pattern {pattern_def['id']}: {e}")

        findings.sort(key=lambda x: {"high": 0, "medium": 1, "low": 2}.get(x["severity"], 3))
        logger.info(f"Static analyzer found {len(findings)} potential issues")
        return findings
