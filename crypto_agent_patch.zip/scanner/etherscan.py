import logging
import requests
import json
import time

logger = logging.getLogger(__name__)

ETHERSCAN_BASE = "https://api.etherscan.io"
API_KEY = None
CHAIN_ID = 1

def configure(api_key, chain_id=1):
    global API_KEY, CHAIN_ID
    API_KEY = api_key
    CHAIN_ID = chain_id

def fetch_contract(address):
    from utils.rate_limiter import rate_limiter
    from utils.stealth import stealth
    from core.database import db

    if not API_KEY:
        logger.error("Etherscan API key not configured")
        return None, None

    rate_limiter.wait("etherscan")
    stealth.random_delay(1, 3)

    url = f"{ETHERSCAN_BASE}/v2/api"
    params = {
        "chainid": CHAIN_ID,
        "module": "contract",
        "action": "getsourcecode",
        "address": address,
        "apikey": API_KEY,
    }

    start = time.time()
    try:
        headers = {"User-Agent": stealth.get_random_user_agent()}
        resp = requests.get(url, params=params, headers=headers, timeout=30)
        duration_ms = int((time.time() - start) * 1000)
        db.record_api_call("etherscan", url, resp.status_code, duration_ms)

        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1" and data.get("result"):
                result = data["result"][0]
                source_code = result.get("SourceCode", "")
                if source_code.startswith("{"):
                    try:
                        parsed = json.loads(source_code)
                        if isinstance(parsed, dict) and "sources" in parsed:
                            sources = []
                            for path, content in parsed["sources"].items():
                                sources.append(f"// File: {path}\n{content.get('content', '')}")
                            source_code = "\n\n".join(sources)
                    except (json.JSONDecodeError, TypeError):
                        pass
                metadata = {
                    "ContractName": result.get("ContractName", "Unknown"),
                    "CompilerVersion": result.get("CompilerVersion", ""),
                    "OptimizationUsed": result.get("OptimizationUsed", "0"),
                    "Runs": result.get("Runs", ""),
                    "EVMVersion": result.get("EVMVersion", ""),
                    "LicenseType": result.get("LicenseType", ""),
                    "Proxy": result.get("Proxy", "0"),
                    "Implementation": result.get("Implementation", ""),
                    "ABI": result.get("ABI", ""),
                }
                logger.info(f"Fetched contract {result.get('ContractName', 'Unknown')} ({len(source_code)} chars)")
                return source_code, metadata
            else:
                logger.warning(f"Etherscan API error: {data.get('message', 'unknown')}")
        else:
            logger.warning(f"Etherscan HTTP {resp.status_code}")

        if resp.status_code == 429:
            logger.warning("Rate limited by Etherscan, backing off...")
            time.sleep(30)

    except requests.exceptions.Timeout:
        logger.error("Etherscan request timed out")
    except requests.exceptions.RequestException as e:
        logger.error(f"Etherscan request failed: {e}")

    return None, None

def get_abi(address):
    if not API_KEY:
        return None

    url = f"{ETHERSCAN_BASE}/v2/api"
    params = {
        "chainid": CHAIN_ID,
        "module": "contract",
        "action": "getabi",
        "address": address,
        "apikey": API_KEY,
    }

    try:
        resp = requests.get(url, params=params, timeout=30)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "1":
                return data.get("result")
    except Exception as e:
        logger.error(f"Failed to fetch ABI: {e}")
    return None
