import logging
import re

logger = logging.getLogger(__name__)

def extract_function_signatures(source_code):
    functions = []
    pattern = r'(function\s+\w+\s*\([^)]*\)\s*(?:\w+\s*)?(?:\{[^}]*\})?)'
    matches = re.findall(pattern, source_code, re.MULTILINE)
    for match in matches:
        functions.append(match.strip())
    return functions

def extract_state_variables(source_code):
    variables = []
    pattern = r'(?:mapping|address|uint\d*|int\d*|bool|string|bytes\d*)\s+(?:public|internal|private)?\s*\w+'
    matches = re.findall(pattern, source_code, re.MULTILINE)
    for match in matches:
        variables.append(match.strip())
    return variables

def extract_modifiers(source_code):
    modifiers = []
    pattern = r'modifier\s+(\w+)\s*\([^)]*\)'
    matches = re.findall(pattern, source_code, re.MULTILINE)
    for match in matches:
        modifiers.append(match)
    return modifiers

def extract_external_calls(source_code):
    calls = []
    pattern = r'(\w+)\.(call|delegatecall|staticcall)\s*\{[^}]*\}\s*\([^)]*\)'
    matches = re.findall(pattern, source_code, re.MULTILINE)
    for match in matches:
        calls.append(f"{match[0]}.{match[1]}")
    return calls

def get_contract_structure(source_code):
    return {
        "functions": extract_function_signatures(source_code),
        "state_variables": extract_state_variables(source_code),
        "modifiers": extract_modifiers(source_code),
        "external_calls": extract_external_calls(source_code),
        "line_count": len(source_code.splitlines()),
        "has_receive": bool(re.search(r'receive\s*\(\s*\)\s*external\s+payable', source_code)),
        "has_fallback": bool(re.search(r'fallback\s*\(\s*\)\s*external', source_code)),
    }
