import logging
import os
import sys
from datetime import datetime
from logging.handlers import RotatingFileHandler

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
RUNS_DIR = os.path.join(LOG_DIR, "runs")
ERRORS_DIR = os.path.join(LOG_DIR, "errors")
DEBUG_DIR = os.path.join(LOG_DIR, "debug")

for d in [LOG_DIR, RUNS_DIR, ERRORS_DIR, DEBUG_DIR]:
    os.makedirs(d, exist_ok=True)

SENSITIVE_KEYS = [
    "api_key", "apikey", "api-key", "token", "authorization",
    "password", "secret", "x-api-key", "bearer", "nvapi", "sk-or"
]

class KeyMaskingFormatter(logging.Formatter):
    def format(self, record):
        msg = super().format(record)
        for key in SENSITIVE_KEYS:
            idx = msg.lower().find(key)
            if idx != -1:
                colon_idx = msg.find(":", idx)
                eq_idx = msg.find("=", idx)
                mask_start = -1
                if colon_idx != -1 and (eq_idx == -1 or colon_idx < eq_idx):
                    mask_start = colon_idx + 1
                elif eq_idx != -1 and (colon_idx == -1 or eq_idx < colon_idx):
                    mask_start = eq_idx + 1
                if mask_start != -1:
                    end_idx = mask_start + 60
                    if end_idx > len(msg):
                        end_idx = len(msg)
                    trailing = msg[end_idx:] if end_idx < len(msg) else ""
                    msg = msg[:mask_start] + "***" + trailing
        return msg

def get_run_logger(run_id):
    today = datetime.now().strftime("%Y-%m-%d")
    run_dir = os.path.join(RUNS_DIR, today)
    os.makedirs(run_dir, exist_ok=True)
    log_file = os.path.join(run_dir, f"{run_id}.log")
    run_logger = logging.getLogger(f"run_{run_id}")
    run_logger.setLevel(logging.DEBUG)
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fmt = KeyMaskingFormatter("%(asctime)s.%(msecs)03d [%(levelname)s] [%(module)s] %(message)s", datefmt="%H:%M:%S")
    fh.setFormatter(fmt)
    run_logger.addHandler(fh)
    return run_logger

def setup_logger():
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.INFO)
    console_fmt = KeyMaskingFormatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S"
    )
    console.setFormatter(console_fmt)
    root_logger.addHandler(console)

    app_log = os.path.join(LOG_DIR, "app.log")
    app_handler = RotatingFileHandler(app_log, maxBytes=10*1024*1024, backupCount=5, encoding="utf-8")
    app_handler.setLevel(logging.INFO)
    app_handler.setFormatter(
        KeyMaskingFormatter("%(asctime)s.%(msecs)03d [%(levelname)s] [%(module)s:%(lineno)d] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    )
    root_logger.addHandler(app_handler)

    debug_log = os.path.join(DEBUG_DIR, f"debug_{datetime.now().strftime('%Y-%m-%d')}.log")
    debug_handler = RotatingFileHandler(debug_log, maxBytes=50*1024*1024, backupCount=3, encoding="utf-8")
    debug_handler.setLevel(logging.DEBUG)
    debug_handler.setFormatter(
        KeyMaskingFormatter("%(asctime)s.%(msecs)03d [%(levelname)s] [%(module)s:%(lineno)d] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    )
    root_logger.addHandler(debug_handler)

    error_log = os.path.join(ERRORS_DIR, f"errors_{datetime.now().strftime('%Y-%m-%d')}.log")
    error_handler = RotatingFileHandler(error_log, maxBytes=20*1024*1024, backupCount=7, encoding="utf-8")
    error_handler.setLevel(logging.WARNING)
    error_handler.setFormatter(
        KeyMaskingFormatter("%(asctime)s.%(msecs)03d [%(levelname)s] [%(module)s:%(lineno)d] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    )
    root_logger.addHandler(error_handler)

    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("pymongo").setLevel(logging.WARNING)

    return root_logger

def mask_api_key(text):
    if not text:
        return text
    for key in SENSITIVE_KEYS:
        idx = text.lower().find(key)
        if idx != -1:
            colon_idx = text.find(":", idx)
            eq_idx = text.find("=", idx)
            mask_start = -1
            if colon_idx != -1 and (eq_idx == -1 or colon_idx < eq_idx):
                mask_start = colon_idx + 1
            elif eq_idx != -1 and (colon_idx == -1 or eq_idx < colon_idx):
                mask_start = eq_idx + 1
            if mask_start != -1:
                end_idx = mask_start + 60
                if end_idx > len(text):
                    end_idx = len(text)
                trailing = text[end_idx:] if end_idx < len(text) else ""
                text = text[:mask_start] + "***" + trailing
    return text
