import logging
import threading
import random

logger = logging.getLogger(__name__)

class ProxyManager:
    def __init__(self):
        self._proxies = []
        self._index = 0
        self._lock = threading.Lock()
        self._blacklisted = set()

    def load(self, proxy_list):
        with self._lock:
            self._proxies = [p.strip() for p in proxy_list if p.strip()]
            logger.info(f"Loaded {len(self._proxies)} proxies")

    def get(self):
        with self._lock:
            if not self._proxies:
                return None
            attempts = 0
            while attempts < len(self._proxies):
                proxy = self._proxies[self._index % len(self._proxies)]
                self._index += 1
                if proxy not in self._blacklisted:
                    return {"http": proxy, "https": proxy}
                attempts += 1
            return None

    def blacklist(self, proxy):
        with self._lock:
            if proxy:
                proxy_str = proxy.get("http", "")
                if proxy_str:
                    self._blacklisted.add(proxy_str)
                    logger.warning(f"Blacklisted proxy: {proxy_str}")

    def reset(self):
        with self._lock:
            self._blacklisted.clear()
            self._index = 0
            logger.info("Proxy blacklist reset")

    def count(self):
        return len(self._proxies)

    def active_count(self):
        return len(self._proxies) - len(self._blacklisted)

proxy_manager = ProxyManager()
