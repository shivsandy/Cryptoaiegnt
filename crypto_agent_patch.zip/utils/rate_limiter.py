import time
import threading
import random
import logging

logger = logging.getLogger(__name__)

class TokenBucket:
    def __init__(self, rate_per_minute, burst=None):
        self.rate_per_minute = rate_per_minute
        self.burst = burst or rate_per_minute
        self.tokens = float(self.burst)
        self.last_refill = time.monotonic()
        self.lock = threading.Lock()

    def _refill(self):
        now = time.monotonic()
        elapsed = now - self.last_refill
        refill = elapsed * (self.rate_per_minute / 60.0)
        self.tokens = min(float(self.burst), self.tokens + refill)
        self.last_refill = now

    def consume(self, tokens=1):
        with self.lock:
            self._refill()
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False

    def wait_and_consume(self, tokens=1):
        while True:
            if self.consume(tokens):
                return
            with self.lock:
                self._refill()
                wait_time = max((tokens - self.tokens) * (60.0 / self.rate_per_minute), 0.1)
            jitter = random.uniform(0.1, 0.5)
            time.sleep(wait_time + jitter)

class RateLimiter:
    def __init__(self):
        self.buckets = {}
        self.lock = threading.Lock()

    def register(self, name, rate_per_minute, burst=None):
        with self.lock:
            self.buckets[name] = TokenBucket(rate_per_minute, burst)
            logger.debug(f"Rate limiter registered: {name} = {rate_per_minute} req/min")

    def wait(self, name, tokens=1):
        with self.lock:
            if name not in self.buckets:
                logger.warning(f"No rate limiter for {name}, using default 10/min")
                self.buckets[name] = TokenBucket(10)
        self.buckets[name].wait_and_consume(tokens)

    def reset(self):
        with self.lock:
            for bucket in self.buckets.values():
                bucket.tokens = float(bucket.burst)
                bucket.last_refill = time.monotonic()
            count = len(self.buckets)
            logger.info(f"Reset {count} rate limiter buckets")
            return count

    def status(self):
        with self.lock:
            return {name: bucket.tokens for name, bucket in self.buckets.items()}

rate_limiter = RateLimiter()
