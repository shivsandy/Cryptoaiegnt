import random
import time
import logging

logger = logging.getLogger(__name__)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.5; rv:126.0) Gecko/20100101 Firefox/126.0",
]

ACCEPT_LANGUAGES = [
    "en-US,en;q=0.9",
    "en-GB,en;q=0.8",
    "en;q=0.9",
    "en-US,en;q=0.8,fr;q=0.6",
]

class StealthManager:
    def __init__(self):
        self._proxy_list = []
        self._proxy_index = 0

    def get_random_user_agent(self):
        return random.choice(USER_AGENTS)

    def get_random_accept_language(self):
        return random.choice(ACCEPT_LANGUAGES)

    def get_headers(self):
        return {
            "User-Agent": self.get_random_user_agent(),
            "Accept": "text/html,application/json,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": self.get_random_accept_language(),
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Cache-Control": "no-cache",
            "Sec-Ch-Ua": '"Not/A)Brand";v="99", "Google Chrome";v="125", "Chromium";v="125"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
        }

    def set_proxies(self, proxy_list):
        self._proxy_list = proxy_list
        logger.info(f"Loaded {len(proxy_list)} proxies")

    def get_next_proxy(self):
        if not self._proxy_list:
            return None
        proxy = self._proxy_list[self._proxy_index % len(self._proxy_list)]
        self._proxy_index += 1
        return {"http": proxy, "https": proxy}

    def random_delay(self, min_sec=2, max_sec=15):
        delay = random.uniform(min_sec, max_sec)
        logger.debug(f"Stealth delay: {delay:.1f}s")
        time.sleep(delay)

    def submission_delay(self):
        delay = random.uniform(180, 480)
        logger.info(f"Submission stealth delay: {delay:.0f}s ({delay/60:.1f} min)")
        time.sleep(delay)

stealth = StealthManager()
