#!/bin/bash
set -e

echo "================================================="
echo "  Crypto Bug Hunter - Uninstall"
echo "================================================="
echo ""

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BASE_DIR"

echo "--- Killing running processes ---"
PIDS=$(pgrep -f "[p]ython.*main\\.py" 2>/dev/null || true)
if [ -n "$PIDS" ]; then
    echo "  Killing process(es): $PIDS"
    kill $PIDS 2>/dev/null || true
    sleep 1
    # Force kill any remaining
    PIDS_REMAINING=$(pgrep -f "[p]ython.*main\\.py" 2>/dev/null || true)
    if [ -n "$PIDS_REMAINING" ]; then
        kill -9 $PIDS_REMAINING 2>/dev/null || true
    fi
    echo "  Processes stopped"
else
    echo "  No running bot processes found"
fi

echo ""
echo "--- Removing cron entries ---"
(crontab -l 2>/dev/null | grep -v "$BASE_DIR" || true) | crontab -
echo "  Cron entries removed"

echo ""
echo "--- Removing start_bot.sh ---"
if [ -f "start_bot.sh" ]; then
    rm -f start_bot.sh
    echo "  start_bot.sh removed"
fi

echo ""
echo "--- Removing virtual environment ---"
if [ -d "venv" ]; then
    rm -rf venv
    echo "  Virtual environment removed"
fi

echo ""
echo "--- Removing apikey_log directory ---"
if [ -d "apikey_log" ]; then
    rm -rf apikey_log
    echo "  apikey_log removed"
fi

echo ""
read -p "Delete all data (logs, reports, scanned contracts)? [y/N]: " DELETE_DATA
if [ "$DELETE_DATA" = "y" ] || [ "$DELETE_DATA" = "Y" ]; then
    echo "  Removing data directories..."
    rm -rf data/credentials 2>/dev/null || true
    rm -rf data/reports 2>/dev/null || true
    rm -rf data/scanned_contracts 2>/dev/null || true
    rm -rf logs 2>/dev/null || true
    echo "  Data removed"
else
    echo "  Keeping data directories"
fi

echo ""
read -p "Delete api.txt? [y/N]: " DELETE_CONFIG
if [ "$DELETE_CONFIG" = "y" ] || [ "$DELETE_CONFIG" = "Y" ]; then
    rm -f api.txt
    echo "  api.txt removed"
else
    echo "  Keeping api.txt"
fi

echo ""
read -p "Delete all Python cache files (*.pyc, __pycache__)? [y/N]: " DELETE_CACHE
if [ "$DELETE_CACHE" = "y" ] || [ "$DELETE_CACHE" = "Y" ]; then
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find . -name "*.pyc" -delete 2>/dev/null || true
    echo "  Cache files removed"
else
    echo "  Keeping cache files"
fi

echo ""
read -p "Delete entire project directory ($BASE_DIR)? [y/N]: " DELETE_PROJECT
if [ "$DELETE_PROJECT" = "y" ] || [ "$DELETE_PROJECT" = "Y" ]; then
    cd ..
    rm -rf "$BASE_DIR"
    echo "  Project directory removed"
else
    echo "  Keeping project directory"
fi

echo ""
echo "================================================="
echo "  Uninstall Complete"
echo "================================================="
