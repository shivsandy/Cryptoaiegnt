import logging
import asyncio

logger = logging.getLogger(__name__)

_application = None
_owner_chat_id = None
_owner_username = "imTerabyte"

def configure(app, chat_id, owner):
    global _application, _owner_chat_id, _owner_username
    _application = app
    _owner_chat_id = chat_id
    _owner_username = owner

async def send_message(text, reply_markup=None, parse_mode="Markdown"):
    if not _application or not _owner_chat_id:
        logger.warning("Telegram notifier not configured")
        return None
    try:
        msg = await _application.bot.send_message(
            chat_id=_owner_chat_id,
            text=text,
            parse_mode=parse_mode,
            reply_markup=reply_markup,
        )
        return msg
    except Exception as e:
        logger.error(f"Telegram send failed: {e}")
        return None

def _send_safe(text, reply_markup=None):
    if not _application:
        logger.warning("Application not initialized for notification")
        return
    try:
        loop = _application.loop
        if loop and loop.is_running():
            asyncio.run_coroutine_threadsafe(
                send_message(text, reply_markup=reply_markup),
                loop,
            )
        else:
            asyncio.run(send_message(text, reply_markup=reply_markup))
    except Exception as e:
        logger.error(f"Failed to send notification: {e}")

def send_approval_request(address, severity, summary, findings, approval_id):
    from telegram.keyboards import approval_keyboard
    text = f"New Scan Complete\n\nContract: `{address}`\nSeverity: {severity.upper()}\n\n{summary}\n\nApprove submission?"
    _send_safe(text, reply_markup=approval_keyboard(approval_id))

def notify_auto_submit(address, severity, findings):
    text = f"Auto-Submitted\n\nContract: `{address}`\nSeverity: {severity.upper()}\nFindings: {', '.join(findings[:3])}"
    _send_safe(text)
