from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def approval_keyboard(approval_id):
    keyboard = [
        [
            InlineKeyboardButton("Approve", callback_data=f"approve_{approval_id}"),
            InlineKeyboardButton("Decline", callback_data=f"decline_{approval_id}"),
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

def approval_list_keyboard(approval_ids):
    buttons = []
    for aid in approval_ids[:10]:
        buttons.append([
            InlineKeyboardButton(f"Approve {aid[:8]}...", callback_data=f"approve_{aid}"),
            InlineKeyboardButton(f"Decline {aid[:8]}...", callback_data=f"decline_{aid}"),
        ])
    if approval_ids:
        buttons.append([
            InlineKeyboardButton("Approve All", callback_data="approve_all"),
            InlineKeyboardButton("Decline All", callback_data="decline_all"),
        ])
    return InlineKeyboardMarkup(buttons) if buttons else None

def main_menu_keyboard():
    keyboard = [
        [
            InlineKeyboardButton("Scan", callback_data="cmd_scan"),
            InlineKeyboardButton("Status", callback_data="cmd_status"),
        ],
        [
            InlineKeyboardButton("Approvals", callback_data="cmd_approvals"),
            InlineKeyboardButton("Balance", callback_data="cmd_balance"),
        ],
        [
            InlineKeyboardButton("Test API", callback_data="cmd_testapi"),
            InlineKeyboardButton("Clear Cache", callback_data="cmd_clearcache"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)
