import logging
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters

logger = logging.getLogger(__name__)

_application = None

def create_bot(token):
    global _application
    _application = Application.builder().token(token).concurrent_updates(True).build()
    return _application

def get_application():
    return _application

def register_handlers(app, handlers_dict):
    for command, handler in handlers_dict.get("commands", {}).items():
        app.add_handler(CommandHandler(command, handler))
    if "callback" in handlers_dict:
        app.add_handler(CallbackQueryHandler(handlers_dict["callback"]))
    if "message" in handlers_dict:
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handlers_dict["message"]))
    logger.info(f"Registered {len(handlers_dict.get('commands', {}))} command handlers")
