import logging
import asyncio
import requests as sync_requests
from datetime import datetime

logger = logging.getLogger(__name__)

_owner_username = "imTerabyte"
_config = {}

def configure(config):
    global _owner_username, _config
    _config = config
    _owner_username = config.get("TELEGRAM_BOT_OWNER", "imTerabyte")

async def _check_owner(update, context):
    user = update.effective_user
    if not user or user.username != _owner_username:
        if update.message:
            await update.message.reply_text("getout you are not authorized")
        elif update.callback_query:
            await update.callback_query.answer("getout you are not authorized")
        return False
    return True

async def _send_long_message(update, context, text):
    if len(text) > 4000:
        for i in range(0, len(text), 3500):
            await update.message.reply_text(text[i:i+3500])
            await asyncio.sleep(0.5)
    else:
        await update.message.reply_text(text)

async def _test_one_service(name, url, method="GET", headers=None, auth=None, params=None, json_data=None, timeout=8):
    def _sync():
        try:
            kwargs = {"timeout": timeout, "headers": headers or {}}
            if auth:
                kwargs["auth"] = auth
            if params:
                kwargs["params"] = params
            if json_data:
                kwargs["json"] = json_data
            if method == "GET":
                resp = sync_requests.get(url, **kwargs)
            else:
                resp = sync_requests.post(url, **kwargs)
            ok = resp.status_code in (200, 201, 204)
            detail = "OK" if ok else f"HTTP {resp.status_code}"
            return (name, ok, detail)
        except Exception as e:
            return (name, False, str(e)[:60])
    return await asyncio.to_thread(_sync)

async def start_command(update, context):
    user = update.effective_user
    if user and user.username == _owner_username:
        await update.message.reply_text("Agent connected press for /help")
    else:
        await update.message.reply_text("getout you are not authorized")

async def help_command(update, context):
    if not await _check_owner(update, context):
        return
    await update.message.reply_text(
        "/info      system uptime and worker status\n"
        "/testapi   test connectivity of all api keys\n"
        "/approvals list of pending approvals for submission\n"
        "/rejected  list of rejections\n"
        "/balance   for both hackerone and immunefi\n"
        "/scan      automatically for bug bounty programs\n"
        "/clearcache clears cache to prevent hanging"
    )

async def info_command(update, context):
    if not await _check_owner(update, context):
        return
    from core.scheduler import scheduler
    status = await asyncio.to_thread(scheduler.worker_status)
    await update.message.reply_text(
        f"System Info\n\n"
        f"Uptime: {status['uptime']}\n"
        f"Started: {status['started_at']}\n"
        f"Scheduler: {'Running' if status['scheduler_running'] else 'Stopped'}\n"
        f"Jobs: {status['active_jobs']}\n"
        f"Total Scans: {status['total_scans']}\n"
        f"Today: {status['today_scans']}\n"
        f"Pending Approvals: {status['pending_approvals']}"
    )

async def testapi_command(update, context):
    if not await _check_owner(update, context):
        return
    progress_msg = await update.message.reply_text("Testing API connections...")
    from config import Config
    cfg = Config()

    tasks = []

    ether_key = cfg.get("ETHERSCAN_API_KEY", "")
    if ether_key:
        tasks.append(_test_one_service("Etherscan", "https://api.etherscan.io/v2/api", params={"chainid": "1", "module": "contract", "action": "getsourcecode", "address": "0x0000000000000000000000000000000000000000", "apikey": ether_key}))
    else:
        tasks.append(asyncio.sleep(0, result=("Etherscan", False, "No API key")))

    for i in range(1, 5):
        key = cfg.get(f"OPENROUTER_API_KEY_{i}", "")
        if key:
            tasks.append(_test_one_service(f"OpenRouter K{i}", "https://openrouter.ai/api/v1/key", headers={"Authorization": f"Bearer {key}"}))
        else:
            tasks.append(asyncio.sleep(0, result=(f"OpenRouter K{i}", False, "No key")))

    nv_key = cfg.get("NVIDIA_API_KEY", "")
    if nv_key:
        tasks.append(_test_one_service("NVIDIA", "https://integrate.api.nvidia.com/v1/models", headers={"Authorization": f"Bearer {nv_key}"}))
    else:
        tasks.append(asyncio.sleep(0, result=("NVIDIA", False, "No key")))

    h1 = cfg.get_hackerone_creds()
    if h1:
        tasks.append(_test_one_service("HackerOne", "https://api.hackerone.com/v1/hackers/me/reports?page[size]=1", auth=(h1["username"], h1["token"])))
    else:
        tasks.append(asyncio.sleep(0, result=("HackerOne", False, "No credentials")))

    imm = cfg.get_immunefi_creds()
    if imm:
        tasks.append(_test_one_service("Immunefi", "https://bugs.immunefi.com"))
    else:
        tasks.append(asyncio.sleep(0, result=("Immunefi", False, "No credentials")))

    try:
        bot_info = await context.bot.get_me()
        tasks.append(asyncio.sleep(0, result=("Telegram", True, f"OK ({bot_info.username})")))
    except Exception as e:
        tasks.append(asyncio.sleep(0, result=("Telegram", False, str(e)[:60])))

    results = await asyncio.gather(*tasks)
    passed = sum(1 for _, ok, _ in results if ok)
    text_lines = ["API Test Results\n"]
    for name, ok, detail in results:
        text_lines.append(f"{'PASS' if ok else 'FAIL'}  {name}: {detail}")
    text_lines.append(f"\n{passed}/{len(results)} services operational")
    await progress_msg.edit_text("\n".join(text_lines))

async def approvals_command(update, context):
    if not await _check_owner(update, context):
        return
    from core.database import db
    from telegram.keyboards import approval_list_keyboard
    pending = await asyncio.to_thread(db.get_pending_approvals)
    if not pending:
        await update.message.reply_text("No pending approvals")
        return
    text_lines = [f"Pending Approvals ({len(pending)})\n"]
    approval_ids = []
    for p in pending:
        aid = str(p["_id"])
        approval_ids.append(aid)
        text_lines.append(f"ID: {aid[:8]}...")
        text_lines.append(f"Contract: {p.get('contract_address', 'N/A')[-10:]}")
        text_lines.append(f"Severity: {p.get('severity', 'N/A')}")
        text_lines.append("---")
    await update.message.reply_text("\n".join(text_lines), reply_markup=approval_list_keyboard(approval_ids))

async def rejected_command(update, context):
    if not await _check_owner(update, context):
        return
    from core.database import db
    rejected = await asyncio.to_thread(db.get_rejected, 20)
    if not rejected:
        await update.message.reply_text("No rejected submissions")
        return
    text_lines = [f"Rejected Submissions ({len(rejected)})\n"]
    for r in rejected:
        text_lines.append(f"Contract: {r.get('contract_address', 'N/A')[-10:]}")
        text_lines.append(f"Severity: {r.get('severity', 'N/A')}")
        text_lines.append(f"Date: {r.get('decided_at', 'N/A')}")
        text_lines.append("---")
    await _send_long_message(update, context, "\n".join(text_lines))

async def balance_command(update, context):
    if not await _check_owner(update, context):
        return
    async def get_h1():
        from submitter.hackerone import get_balance as h1b
        res = await asyncio.to_thread(h1b)
        if "error" in res:
            return f"HackerOne: {res['error']}"
        return f"HackerOne Balance: \${res.get('balance', 0.0):.2f}"
    async def get_imm():
        from submitter.immunefi import get_balance as imb
        res = await asyncio.to_thread(imb)
        return f"Immunefi: {res.get('status', 'Unknown')}"
    results = await asyncio.gather(get_h1(), get_imm())
    await update.message.reply_text("Balance Info\n\n" + "\n".join(results))

async def scan_command(update, context):
    if not await _check_owner(update, context):
        return
    from core.database import db
    args = context.args
    if args:
        address = args[0].strip()
        if not address.startswith("0x") or len(address) != 42:
            await update.message.reply_text("Invalid address format. Expected 0x... (42 chars)")
            return
        await update.message.reply_text(f"Scanning {address}...")
        await asyncio.to_thread(db.add_to_watchlist, address)
    else:
        watchlist_item = await asyncio.to_thread(db.get_next_watchlist_item)
        if watchlist_item:
            address = watchlist_item["address"]
            await update.message.reply_text(f"Auto-discovered contract: {address}\nScanning...")
        else:
            await update.message.reply_text("No contracts in watchlist. Use: /scan 0x...")
            return

    from core.pipeline import pipeline
    loop = asyncio.get_running_loop()
    result = await loop.run_in_executor(None, pipeline.execute, address)

    if result["status"] == "completed":
        text = f"Scan Complete\n\nContract: {result.get('contract_name', 'Unknown')}\nSeverity: {result['severity'].upper()}\nFindings: {len(result.get('findings', []))}\nReport: {result.get('report_path', 'N/A')}"
        if result.get("hackerone_submission"):
            text += f"\nSubmitted: {result['hackerone_submission']}"
        await update.message.reply_text(text)
    elif result["status"] == "skipped":
        await update.message.reply_text(f"Skipped: {result.get('reason', 'Unknown')}")
    else:
        await update.message.reply_text(f"Failed: {result.get('reason', 'Unknown')}")

async def clearcache_command(update, context):
    if not await _check_owner(update, context):
        return
    from core.database import db
    from utils.rate_limiter import rate_limiter
    from utils.proxy_manager import proxy_manager

    counts = []
    cached = await asyncio.to_thread(db.clear_cache)
    counts.append(f"{cached} MongoDB cache docs")
    counts.append(f"{rate_limiter.reset()} rate limiter buckets")
    proxy_manager.reset()
    counts.append("proxy blacklist reset")

    await update.message.reply_text("Cache cleared\n" + "\n".join(f"- {c}" for c in counts))

async def callback_handler(update, context):
    query = update.callback_query
    user = update.effective_user
    if not user or user.username != _owner_username:
        await query.answer("getout you are not authorized")
        return

    data = query.data
    await query.answer()
    from core.database import db

    if data == "approve_all":
        pending = await asyncio.to_thread(db.get_pending_approvals)
        for p in pending:
            await asyncio.to_thread(db.update_approval, p["_id"], "approved")
        await query.edit_message_text(f"Approved all {len(pending)} pending")
    elif data == "decline_all":
        pending = await asyncio.to_thread(db.get_pending_approvals)
        for p in pending:
            await asyncio.to_thread(db.update_approval, p["_id"], "declined")
        await query.edit_message_text(f"Declined all {len(pending)} pending")
    elif data.startswith("approve_"):
        from bson.objectid import ObjectId
        try:
            await asyncio.to_thread(db.update_approval, ObjectId(data.replace("approve_", "")), "approved")
            await query.edit_message_text("Approved")
        except Exception as e:
            await query.edit_message_text(f"Error: {str(e)[:60]}")
    elif data.startswith("decline_"):
        from bson.objectid import ObjectId
        try:
            await asyncio.to_thread(db.update_approval, ObjectId(data.replace("decline_", "")), "declined")
            await query.edit_message_text("Declined")
        except Exception as e:
            await query.edit_message_text(f"Error: {str(e)[:60]}")
    elif data.startswith("cmd_"):
        cmd = data.replace("cmd_", "")
        if cmd == "approvals":
            pending = await asyncio.to_thread(db.get_pending_approvals)
            if pending:
                from telegram.keyboards import approval_list_keyboard
                ids = [str(p["_id"]) for p in pending]
                await query.edit_message_text(f"{len(pending)} pending", reply_markup=approval_list_keyboard(ids))
            else:
                await query.edit_message_text("No pending approvals")
        else:
            await query.edit_message_text(f"Use /{cmd} command")
