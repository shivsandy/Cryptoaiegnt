import logging
import os

logger = logging.getLogger(__name__)

class Config:
    def __init__(self, api_txt_path=None):
        if api_txt_path is None:
            self.base_dir = os.path.dirname(os.path.abspath(__file__))
            api_txt_path = os.path.join(self.base_dir, "api.txt")
        else:
            self.base_dir = os.path.dirname(api_txt_path)
        self.api_txt_path = api_txt_path
        self.config = {}
        self._load_api_txt()

    def _load_api_txt(self):
        if not os.path.exists(self.api_txt_path):
            logger.warning(f"api.txt not found at {self.api_txt_path}")
            return
        with open(self.api_txt_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("="):
                    continue
                if "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip()
                    if value and not value.startswith("__") and not value.startswith("YOUR_"):
                        self.config[key] = value

    def get(self, key, default=""):
        return self.config.get(key, default)

    def get_openrouter_keys(self):
        keys = []
        for i in range(1, 5):
            key = self.get(f"OPENROUTER_API_KEY_{i}", "")
            if key:
                keys.append(key)
        return keys

    def get_hackerone_creds(self):
        username = self.get("HACKERONE_API_USERNAME", "")
        token = self.get("HACKERONE_API_TOKEN", "")
        if username and token:
            return {"username": username, "token": token}
        return None

    def get_immunefi_creds(self):
        email = self.get("IMMUNEFI_EMAIL", "")
        password = self.get("IMMUNEFI_PASSWORD", "")
        twofa = self.get("IMMUNEFI_2FA_SECRET", "")
        if email and password:
            return {"email": email, "password": password, "2fa": twofa}
        return None

    def get_all(self):
        safe_config = {}
        for k, v in self.config.items():
            lowered = k.lower()
            if any(s in lowered for s in ["api_key", "apikey", "token", "secret", "password"]):
                safe_config[k] = v[:8] + "..." if len(v) > 8 else "***"
            else:
                safe_config[k] = v
        return safe_config

    def is_valid(self):
        required = ["ETHERSCAN_API_KEY", "TELEGRAM_BOT_TOKEN"]
        missing = [k for k in required if not self.get(k)]
        if missing:
            logger.warning(f"Missing required config: {missing}")
            return False
        return True
