import logging
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)

class BaseSubmitter(ABC):
    def __init__(self, name):
        self.name = name

    @abstractmethod
    def submit(self, report_data, submission_prompt=""):
        pass

    @abstractmethod
    def test_connection(self):
        pass

    @abstractmethod
    def get_balance(self):
        pass
