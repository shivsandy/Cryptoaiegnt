import logging
import os
import json
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

CREDENTIALS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "credentials")
VAULT_FILE = os.path.join(CREDENTIALS_DIR, "vault.enc")
KEY_FILE = os.path.join(CREDENTIALS_DIR, ".vault_key")

class AuthManager:
    def __init__(self):
        self._cipher = None
        self._credentials = {}

    def initialize(self, vault_key=None):
        os.makedirs(CREDENTIALS_DIR, exist_ok=True)
        if vault_key:
            self._cipher = Fernet(vault_key.encode() if len(vault_key) > 43 else vault_key)
        elif os.path.exists(KEY_FILE):
            with open(KEY_FILE, "r") as f:
                key = f.read().strip()
            self._cipher = Fernet(key.encode())
        else:
            key = Fernet.generate_key()
            self._cipher = Fernet(key)
            with open(KEY_FILE, "w") as f:
                f.write(key.decode())
            os.chmod(KEY_FILE, 0o400)
            logger.info("Vault encryption key created")
        self._load_vault()

    def _load_vault(self):
        if os.path.exists(VAULT_FILE):
            try:
                with open(VAULT_FILE, "rb") as f:
                    encrypted = f.read()
                decrypted = self._cipher.decrypt(encrypted)
                self._credentials = json.loads(decrypted.decode())
                logger.info("Vault credentials loaded")
            except Exception as e:
                logger.warning(f"Failed to load vault: {e}")
                self._credentials = {}

    def save_credentials(self, credentials_dict):
        self._credentials.update(credentials_dict)
        try:
            encrypted = self._cipher.encrypt(json.dumps(self._credentials).encode())
            with open(VAULT_FILE, "wb") as f:
                f.write(encrypted)
            os.chmod(VAULT_FILE, 0o600)
            logger.info("Vault credentials saved")
            return True
        except Exception as e:
            logger.error(f"Failed to save vault: {e}")
            return False

    def get(self, key, default=None):
        return self._credentials.get(key, default)

    def get_hackerone_creds(self):
        username = self._credentials.get("HACKERONE_API_USERNAME", "")
        token = self._credentials.get("HACKERONE_API_TOKEN", "")
        if username and token:
            return {"username": username, "token": token}
        return None

    def get_immunefi_creds(self):
        email = self._credentials.get("IMMUNEFI_EMAIL", "")
        password = self._credentials.get("IMMUNEFI_PASSWORD", "")
        twofa = self._credentials.get("IMMUNEFI_2FA_SECRET", "")
        if email and password:
            return {"email": email, "password": password, "2fa": twofa}
        return None

    def has_credentials(self):
        return bool(self._credentials)

    def clear(self):
        self._credentials = {}
        if os.path.exists(VAULT_FILE):
            os.remove(VAULT_FILE)
        if os.path.exists(KEY_FILE):
            os.remove(KEY_FILE)
        logger.info("Vault cleared")

auth_manager = AuthManager()
