import logging
import requests
import json
import time

logger = logging.getLogger(__name__)

HACKERONE_API_BASE = "https://api.hackerone.com/v1"

_username = None
_token = None

def configure(username, token):
    global _username, _token
    _username = username
    _token = token

def submit_hackerone(report_data, submission_prompt=""):
    from utils.stealth import stealth
    from utils.rate_limiter import rate_limiter
    from core.database import db
    from ai.llm_manager import generate_submission_body

    if not _username or not _token:
        logger.warning("HackerOne credentials not configured")
        return None

    logger.info("Generating submission body...")
    body = generate_submission_body(report_data)
    if submission_prompt:
        body = f"{submission_prompt}\n\n{body}"

    team_handle = report_data.get("team_handle", "")
    if not team_handle:
        logger.warning("No team_handle specified for HackerOne")
        return None

    severity = report_data.get("severity", "medium").lower()
    if severity not in ("none", "low", "medium", "high", "critical"):
        severity = "medium"

    payload = {
        "data": {
            "type": "report",
            "attributes": {
                "team_handle": team_handle,
                "title": report_data.get("title", "Security Vulnerability Report"),
                "vulnerability_information": body,
                "impact": report_data.get("impact", "Security impact as described"),
                "severity_rating": severity,
            }
        }
    }

    stealth.submission_delay()
    rate_limiter.wait("hackerone")
    start = time.time()

    try:
        resp = requests.post(
            f"{HACKERONE_API_BASE}/hackers/reports",
            auth=(_username, _token),
            json=payload,
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=60,
        )
        duration_ms = int((time.time() - start) * 1000)
        db.record_api_call("hackerone_submit", HACKERONE_API_BASE, resp.status_code, duration_ms)

        if resp.status_code in (200, 201):
            result = resp.json()
            report_id = result.get("data", {}).get("id", "unknown")
            logger.info(f"HackerOne submission successful: report #{report_id}")
            return str(report_id)
        elif resp.status_code == 429:
            logger.warning("HackerOne rate limited")
            time.sleep(60)
        else:
            logger.warning(f"HackerOne submission failed: HTTP {resp.status_code} - {resp.text[:200]}")

    except Exception as e:
        logger.error(f"HackerOne submission error: {e}")

    return None

def test_connection():
    if not _username or not _token:
        return False, "Not configured"
    try:
        resp = requests.get(
            f"{HACKERONE_API_BASE}/hackers/me/reports?page[size]=1",
            auth=(_username, _token),
            timeout=15,
        )
        if resp.status_code == 200:
            return True, "OK"
        return False, f"HTTP {resp.status_code}"
    except Exception as e:
        return False, str(e)

def get_balance():
    if not _username or not _token:
        return {"error": "Not configured"}
    try:
        resp = requests.get(
            f"{HACKERONE_API_BASE}/hackers/payments/balance",
            auth=(_username, _token),
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json().get("data", {})
            balance = data.get("balance", 0.0)
            return {"status": "connected", "balance": balance}
        return {"status": "error", "code": resp.status_code}
    except Exception as e:
        return {"error": str(e)}
