import logging
import time
import re

logger = logging.getLogger(__name__)

_email = None
_password = None
_twofa = None

def configure(email, password, twofa=""):
    global _email, _password, _twofa
    _email = email
    _password = password
    _twofa = twofa

def submit_immunefi(report_data, submission_prompt=""):
    from utils.stealth import stealth
    from utils.rate_limiter import rate_limiter
    from core.database import db
    from ai.llm_manager import generate_submission_body

    if not _email or not _password:
        logger.warning("Immunefi credentials not configured")
        return None

    logger.info("Immunefi submission requires web dashboard (no public API)")
    logger.info("Generating submission body for manual reference...")

    body = generate_submission_body(report_data)
    if submission_prompt:
        body = re.sub(r'[\U0001F300-\U0001FAFF]', '', f"{submission_prompt}\n\n{body}")
        body = re.sub(r'[\u2600-\u27BF]', '', body)

    report_path = f"data/reports/immunefi_ready_{report_data.get('contract_address', 'unknown')[-6:]}.txt"
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(body)
        logger.info(f"Immunefi report saved to {report_path} for manual submission")
    except Exception as e:
        logger.error(f"Failed to save Immunefi report: {e}")

    return None

def test_connection():
    if not _email or not _password:
        return False, "Not configured"
    try:
        import requests
        resp = requests.get(
            "https://bugs.immunefi.com/api/health",
            timeout=15,
        )
        if resp.status_code == 200:
            return True, "OK (dashboard reachable)"
        return False, f"HTTP {resp.status_code}"
    except Exception as e:
        return False, str(e)

def get_balance():
    return {"status": "requires_web_login", "note": "Immunefi wallet balance available via dashboard at immunefi.com/dashboard"}
