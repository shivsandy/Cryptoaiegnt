import logging
import hashlib
from datetime import datetime, timedelta
from bson.objectid import ObjectId
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.server_api import ServerApi
from pymongo.errors import DuplicateKeyError

logger = logging.getLogger(__name__)

class Database:
    def __init__(self):
        self.client = None
        self.db = None

    def connect(self, uri, db_name="bug_bounty_hunter"):
        try:
            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000, server_api=ServerApi('1'))
            self.client.admin.command("ping")
            self.db = self.client[db_name]
            self._ensure_indexes()
            logger.info(f"Connected to MongoDB: {db_name}")
            return True
        except Exception as e:
            logger.error(f"MongoDB connection failed: {e}")
            return False

    def _ensure_indexes(self):
        self.db.contracts.create_index([("address", ASCENDING)], unique=True)
        self.db.contracts.create_index([("content_hash", ASCENDING)])
        self.db.scans.create_index([("contract_address", ASCENDING), ("created_at", DESCENDING)])
        self.db.scans.create_index([("status", ASCENDING)])
        self.db.approvals.create_index([("status", ASCENDING), ("created_at", DESCENDING)])
        self.db.submissions.create_index([("scan_id", ASCENDING), ("portal", ASCENDING)], unique=True)
        self.db.watchlist.create_index([("address", ASCENDING)], unique=True)
        self.db.watchlist.create_index([("next_scan_at", ASCENDING)])

    def is_contract_scanned(self, address):
        addr = address.lower()
        existing = self.db.contracts.find_one({"address": addr})
        return existing is not None

    def is_duplicate_content(self, source_code):
        content_hash = hashlib.sha256(source_code.encode("utf-8")).hexdigest()
        existing = self.db.contracts.find_one({"content_hash": content_hash})
        return existing, content_hash

    def store_contract(self, address, source_code, metadata):
        addr = address.lower()
        content_hash = hashlib.sha256(source_code.encode("utf-8")).hexdigest()
        doc = {
            "address": addr,
            "content_hash": content_hash,
            "source_code": source_code,
            "metadata": metadata,
            "created_at": datetime.utcnow(),
            "scan_count": 0,
        }
        try:
            self.db.contracts.insert_one(doc)
            logger.info(f"Stored contract {addr}")
            return True
        except DuplicateKeyError:
            logger.debug(f"Contract {addr} already exists")
            return False

    def create_scan(self, address, run_id):
        doc = {
            "run_id": run_id,
            "contract_address": address.lower(),
            "status": "pending",
            "severity": None,
            "findings": [],
            "ai_analysis": None,
            "report_path": None,
            "created_at": datetime.utcnow(),
            "completed_at": None,
        }
        result = self.db.scans.insert_one(doc)
        return str(result.inserted_id)

    def update_scan(self, scan_id, updates):
        if isinstance(scan_id, str):
            scan_id = ObjectId(scan_id)
        self.db.scans.update_one({"_id": scan_id}, {"$set": updates})

    def is_scan_in_progress(self, address):
        existing = self.db.scans.find_one(
            {"contract_address": address.lower(), "status": {"$in": ["pending", "scanning"]}}
        )
        return existing is not None

    def create_approval(self, scan_id, contract_address, severity, summary):
        doc = {
            "scan_id": scan_id,
            "contract_address": contract_address.lower(),
            "severity": severity,
            "summary": summary,
            "status": "pending",
            "created_at": datetime.utcnow(),
            "decided_at": None,
            "decision": None,
        }
        result = self.db.approvals.insert_one(doc)
        return str(result.inserted_id)

    def get_pending_approvals(self):
        cursor = self.db.approvals.find({"status": "pending"}).sort("created_at", DESCENDING)
        return list(cursor)

    def update_approval(self, approval_id, decision):
        if isinstance(approval_id, str):
            approval_id = ObjectId(approval_id)
        self.db.approvals.update_one(
            {"_id": approval_id},
            {"$set": {"status": "decided", "decision": decision, "decided_at": datetime.utcnow()}}
        )

    def create_submission(self, scan_id, portal, report_data):
        doc = {
            "scan_id": scan_id,
            "portal": portal,
            "report_data": report_data,
            "status": "pending",
            "submission_id": None,
            "response": None,
            "created_at": datetime.utcnow(),
        }
        try:
            result = self.db.submissions.insert_one(doc)
            return str(result.inserted_id)
        except DuplicateKeyError:
            logger.warning(f"Duplicate submission for scan {scan_id} on {portal}")
            return None

    def update_submission(self, submission_id, status, submission_id_val=None, response=None):
        if isinstance(submission_id, str):
            submission_id = ObjectId(submission_id)
        updates = {"status": status}
        if submission_id_val:
            updates["submission_id"] = submission_id_val
        if response:
            updates["response"] = response
        self.db.submissions.update_one({"_id": submission_id}, {"$set": updates})

    def get_rejected(self, limit=20):
        cursor = self.db.approvals.find({"decision": "declined"}).sort("created_at", DESCENDING).limit(limit)
        return list(cursor)

    def add_to_watchlist(self, address, source="manual"):
        addr = address.lower()
        try:
            self.db.watchlist.insert_one({
                "address": addr,
                "source": source,
                "added_at": datetime.utcnow(),
                "next_scan_at": datetime.utcnow(),
                "scan_count": 0,
            })
            return True
        except DuplicateKeyError:
            return False

    def get_next_watchlist_item(self):
        doc = self.db.watchlist.find_one_and_update(
            {"next_scan_at": {"$lte": datetime.utcnow()}},
            {"$set": {"next_scan_at": datetime.utcnow() + timedelta(hours=24)}},
            sort=[("next_scan_at", ASCENDING)],
        )
        return doc

    def record_api_call(self, service, url, status_code, duration_ms, retry_count=0):
        doc = {
            "service": service,
            "url": url,
            "status_code": status_code,
            "duration_ms": duration_ms,
            "retry_count": retry_count,
            "timestamp": datetime.utcnow(),
        }
        self.db.api_calls.insert_one(doc)

    def log_error(self, module, error_msg, traceback_str=None, scan_id=None):
        doc = {
            "module": module,
            "error": error_msg,
            "traceback": traceback_str,
            "scan_id": scan_id,
            "timestamp": datetime.utcnow(),
        }
        self.db.errors.insert_one(doc)

    def get_scan_stats(self):
        today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        total = self.db.scans.count_documents({})
        today_count = self.db.scans.count_documents({"created_at": {"$gte": today}})
        pending_approvals = self.db.approvals.count_documents({"status": "pending"})
        return {
            "total_scans": total,
            "today_scans": today_count,
            "pending_approvals": pending_approvals,
        }

    def clear_cache(self):
        count = 0
        for collection in ["api_calls", "scan_logs"]:
            result = self.db[collection].delete_many({})
            count += result.deleted_count
        logger.info(f"Cleared {count} cache documents from MongoDB")
        return count

    def close(self):
        if self.client:
            self.client.close()

db = Database()
