import logging
import os
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)

class ScanPipeline:
    def execute(self, address):
        from utils.logger import get_run_logger
        from core.database import db
        from scanner.etherscan import fetch_contract
        from scanner.static_analyzer import StaticAnalyzer
        from scanner.bounty_checker import check_bounty_eligibility
        from ai.llm_manager import analyze_with_fallback
        from reporter.generator import ReportGenerator
        from telegram.notifier import send_approval_request, notify_auto_submit
        from config import Config

        run_id = f"scan_{address[-6:]}_{datetime.now().strftime('%H%M%S')}"
        run_logger = get_run_logger(run_id)
        run_logger.info(f"Starting scan for {address}")

        scan_id = None
        try:
            run_logger.info("Checking MongoDB for duplicate contract")
            if db.is_contract_scanned(address):
                run_logger.warning(f"Contract {address} already scanned")
                return {"status": "skipped", "reason": "already_scanned"}
            if db.is_scan_in_progress(address):
                run_logger.warning(f"Scan already in progress for {address}")
                return {"status": "skipped", "reason": "already_in_progress"}

            scan_id = db.create_scan(address, run_id)
            db.update_scan(scan_id, {"status": "fetching"})
            run_logger.info("Fetching contract from Etherscan...")
            source_code, metadata = fetch_contract(address)
            if not source_code:
                run_logger.error("Failed to fetch contract source")
                db.update_scan(scan_id, {"status": "failed", "error": "fetch_failed"})
                return {"status": "failed", "reason": "fetch_failed"}

            run_logger.info(f"Source fetched ({len(source_code)} lines)")
            existing_dup, content_hash = db.is_duplicate_content(source_code)
            if existing_dup:
                run_logger.warning(f"Duplicate content (same as {existing_dup['address']})")
                db.update_scan(scan_id, {"status": "skipped", "reason": "duplicate_content"})
                return {"status": "skipped", "reason": "duplicate_content", "original": existing_dup["address"]}

            db.store_contract(address, source_code, metadata)

            run_logger.info("Checking bounty eligibility...")
            cfg_pipe = Config()
            h1_creds = cfg_pipe.get_hackerone_creds()
            platform, platform_name = check_bounty_eligibility(address, h1_creds)
            if platform:
                run_logger.info(f"Eligible for {platform}: {platform_name}")
            else:
                run_logger.info("Not found on active bounty programs")
                db.update_scan(scan_id, {"status": "completed", "note": "not_on_bounty"})
                return {"status": "completed", "note": "not_on_bounty"}

            db.update_scan(scan_id, {"status": "analyzing"})
            run_logger.info("Running static analysis...")
            static_analyzer = StaticAnalyzer()
            static_findings = static_analyzer.analyze(source_code)
            run_logger.info(f"Static analysis: {len(static_findings)} patterns found")

            db.update_scan(scan_id, {"status": "ai_analysis"})
            run_logger.info("Running AI analysis...")
            ai_analysis = analyze_with_fallback(source_code, metadata.get("ContractName", "Unknown"))
            if not ai_analysis:
                run_logger.error("AI analysis failed")
                db.update_scan(scan_id, {"status": "failed", "error": "ai_failed"})
                return {"status": "failed", "reason": "ai_failed"}

            run_logger.info(f"AI analysis complete: {len(ai_analysis.get('findings', []))} vulnerabilities")

            db.update_scan(scan_id, {"status": "generating_report"})
            run_logger.info("Generating report...")
            generator = ReportGenerator()
            report_data = generator.generate(address, source_code, metadata, static_findings, ai_analysis)
            team_handle = platform_name.lower().replace(" ", "_") if platform_name else ""
            all_findings_text = "\n".join(
                f"{f.get('title', '')}: {f.get('description', '')}"
                for f in ai_analysis.get("findings", [])
            )
            severity = ai_analysis.get("overall_severity", "low").lower()
            report_data["team_handle"] = team_handle
            report_data["platform"] = platform
            report_data["description"] = ai_analysis.get("summary", all_findings_text[:2000])
            report_data["impact"] = "; ".join(
                f.get("impact", "") for f in ai_analysis.get("findings", []) if f.get("impact")
            )[:2000] or "Potential loss of funds or contract state manipulation"
            report_data["severity"] = severity
            report_data["recommendation"] = "; ".join(
                f.get("recommendation", "") for f in ai_analysis.get("findings", []) if f.get("recommendation")
            )[:2000] or "Review and patch the identified vulnerabilities"
            report_data["proof_of_concept"] = "See attached report for detailed PoC"
            report_path = generator.save_report(address, report_data)
            run_logger.info(f"Report saved to {report_path}")

            db.update_scan(scan_id, {
                "status": "completed",
                "severity": severity,
                "bounty_platform": platform,
                "findings": static_findings + ai_analysis.get("findings", []),
                "ai_analysis": ai_analysis,
                "report_path": report_path,
                "completed_at": datetime.utcnow(),
            })

            findings_summary = []
            for f in ai_analysis.get("findings", []):
                findings_summary.append(f"{f.get('title', 'Unknown')} ({f.get('severity', 'N/A')})")

            result = {
                "status": "completed",
                "scan_id": scan_id,
                "severity": severity,
                "findings": findings_summary,
                "report_path": report_path,
                "contract_name": metadata.get("ContractName", "Unknown"),
                "bounty_platform": platform,
            }

            if severity in ("high", "critical"):
                run_logger.info(f"{severity.upper()} severity - auto-submitting")
                from submitter.immunefi import submit_immunefi
                from submitter.hackerone import submit_hackerone
                submission_prompt = "Act as a professional security researcher bug hunter and write the email and submit without any emoji to the platforms"
                try:
                    sub_id = submit_hackerone(report_data, submission_prompt)
                    if sub_id:
                        db.create_submission(scan_id, "hackerone", report_data)
                        result["hackerone_submission"] = sub_id
                        run_logger.info(f"Submitted to HackerOne: {sub_id}")
                except Exception as e:
                    run_logger.error(f"HackerOne submission failed: {e}")
                notify_auto_submit(address, severity, findings_summary)
            else:
                run_logger.info(f"{severity.upper()} severity - awaiting approval")
                summary = f"Contract: {metadata.get('ContractName', 'Unknown')}\nSeverity: {severity}\nFindings: {', '.join(findings_summary)}"
                approval_id = db.create_approval(scan_id, address, severity, summary)
                send_approval_request(address, severity, summary, findings_summary, approval_id)

            run_logger.info("Scan complete")
            return result

        except Exception as e:
            run_logger.error(f"Pipeline error: {e}", exc_info=True)
            logger.error(f"Pipeline error for {address}: {e}")
            if scan_id:
                db.update_scan(scan_id, {"status": "failed", "error": str(e)})
            db.log_error("pipeline", str(e), scan_id=scan_id)
            return {"status": "failed", "reason": str(e)}

pipeline = ScanPipeline()
