import logging
import threading
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

logger = logging.getLogger(__name__)

class ScanScheduler:
    def __init__(self):
        self.scheduler = BackgroundScheduler(daemon=True, max_instances=5)
        self._start_time = datetime.now()
        self._jobs = {}

    def start(self, scan_callback=None, interval_hours=6):
        if scan_callback:
            job = self.scheduler.add_job(
                scan_callback,
                IntervalTrigger(hours=interval_hours),
                id="auto_scan",
                name=f"Auto scan every {interval_hours}h",
                replace_existing=True,
            )
            self._jobs["auto_scan"] = job
            logger.info(f"Scheduled auto-scan every {interval_hours} hours")

        self.scheduler.add_job(
            self._health_check,
            IntervalTrigger(hours=1),
            id="health_check",
            name="Hourly health check",
            replace_existing=True,
        )

        self.scheduler.start()
        logger.info(f"Scan scheduler started at {self._start_time}")

    def stop(self):
        if self.scheduler.running:
            self.scheduler.shutdown(wait=False)
            logger.info("Scheduler stopped")

    def _health_check(self):
        logger.debug("Scheduler health check OK")

    def uptime(self):
        delta = datetime.now() - self._start_time
        days = delta.days
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{days}d {hours}h {minutes}m {seconds}s"

    def worker_status(self):
        from core.database import db
        stats = db.get_scan_stats()
        from utils.rate_limiter import rate_limiter
        rl_status = rate_limiter.status()
        return {
            "uptime": self.uptime(),
            "started_at": self._start_time.strftime("%Y-%m-%d %H:%M:%S"),
            "scheduler_running": self.scheduler.running,
            "active_jobs": len(self.scheduler.get_jobs()),
            "job_details": [{"id": j.id, "name": j.name, "next_run": str(j.next_run_time)} for j in self.scheduler.get_jobs()],
            "total_scans": stats["total_scans"],
            "today_scans": stats["today_scans"],
            "pending_approvals": stats["pending_approvals"],
            "rate_limiter_tokens": rl_status,
        }

scheduler = ScanScheduler()
