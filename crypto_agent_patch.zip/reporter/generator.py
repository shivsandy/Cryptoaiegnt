import logging
import os
from datetime import datetime

logger = logging.getLogger(__name__)

REPORTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "reports")

class ReportGenerator:
    def generate(self, address, source_code, metadata, static_findings, ai_analysis):
        contract_name = metadata.get("ContractName", "Unknown")
        severity = ai_analysis.get("overall_severity", "medium").upper()
        risk_score = ai_analysis.get("risk_score", 5)

        findings = []
        for f in static_findings:
            findings.append(f)
        for f in ai_analysis.get("findings", []):
            if not any(existing.get("title") == f.get("title") for existing in findings):
                findings.append(f)

        report = {
            "title": f"Security Audit Report: {contract_name}",
            "contract_name": contract_name,
            "contract_address": address,
            "compiler": metadata.get("CompilerVersion", "Unknown"),
            "evm_version": metadata.get("EVMVersion", "Default"),
            "optimization": "Enabled" if metadata.get("OptimizationUsed") == "1" else "Disabled",
            "license": metadata.get("LicenseType", "None"),
            "audit_date": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
            "overall_severity": severity,
            "risk_score": risk_score,
            "summary": ai_analysis.get("summary", "No summary provided."),
            "findings": [],
            "total_findings": len(findings),
            "severity_counts": {"critical": 0, "high": 0, "medium": 0, "low": 0},
        }

        for i, finding in enumerate(findings, 1):
            sev = finding.get("severity", "low").lower()
            report["severity_counts"][sev] = report["severity_counts"].get(sev, 0) + 1
            report["findings"].append({
                "id": i,
                "title": finding.get("title", "Unknown"),
                "severity": sev.upper(),
                "description": finding.get("description", ""),
                "impact": finding.get("impact", ""),
                "location": finding.get("location", ""),
                "recommendation": finding.get("recommendation", ""),
                "code_snippet": finding.get("code_snippet", finding.get("context", "")),
            })

        return report

    def save_report(self, address, report_data):
        os.makedirs(REPORTS_DIR, exist_ok=True)
        short_addr = address[-6:]
        filename = f"audit_{short_addr}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        filepath = os.path.join(REPORTS_DIR, filename)

        md = self._to_markdown(report_data)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(md)

        logger.info(f"Report saved: {filepath}")
        return filepath

    def _to_markdown(self, report):
        lines = []
        lines.append(f"# Security Audit Report: {report['contract_name']}")
        lines.append("")
        lines.append(f"**Audit Date:** {report['audit_date']}")
        lines.append(f"**Contract:** `{report['contract_address']}`")
        lines.append(f"**Compiler:** {report['compiler']}")
        lines.append(f"**EVM Version:** {report['evm_version']}")
        lines.append(f"**Optimization:** {report['optimization']}")
        lines.append(f"**License:** {report['license']}")
        lines.append("")
        lines.append("## Executive Summary")
        lines.append("")
        sev = report["overall_severity"]
        sev_indicators = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢"}
        indicator = sev_indicators.get(sev, "⚪")
        lines.append(f"**Overall Severity:** {indicator} {sev}")
        lines.append(f"**Risk Score:** {report['risk_score']}/10")
        lines.append(f"**Total Findings:** {report['total_findings']}")
        counts = report["severity_counts"]
        lines.append(f"- Critical: {counts.get('critical', 0)} | High: {counts.get('high', 0)} | Medium: {counts.get('medium', 0)} | Low: {counts.get('low', 0)}")
        lines.append("")
        lines.append("### Summary")
        lines.append("")
        lines.append(report["summary"])
        lines.append("")
        lines.append("## Findings")
        lines.append("")

        for finding in report["findings"]:
            sev_icon = sev_indicators.get(finding["severity"], "⚪")
            lines.append(f"### {finding['id']}. {sev_icon} {finding['title']}")
            lines.append("")
            lines.append(f"**Severity:** {finding['severity']}")
            lines.append("")
            lines.append(f"**Description:**")
            lines.append(f"{finding['description']}")
            lines.append("")
            if finding.get("impact"):
                lines.append(f"**Impact:**")
                lines.append(f"{finding['impact']}")
                lines.append("")
            if finding.get("location"):
                lines.append(f"**Location:** `{finding['location']}`")
                lines.append("")
            if finding.get("code_snippet"):
                lines.append("**Vulnerable Code:**")
                lines.append(f"```solidity")
                lines.append(f"{finding['code_snippet']}")
                lines.append("```")
                lines.append("")
            if finding.get("recommendation"):
                lines.append(f"**Recommendation:**")
                lines.append(f"{finding['recommendation']}")
                lines.append("")
            lines.append("---")
            lines.append("")

        lines.append("")
        lines.append("---")
        lines.append("*This report was generated by Crypto Security AI Bug Bounty Hunter*")
        return "\n".join(lines)
