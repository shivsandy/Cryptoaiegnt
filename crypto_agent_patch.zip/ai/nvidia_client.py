import logging
import requests
import json
import time

logger = logging.getLogger(__name__)

NVIDIA_BASE = "https://integrate.api.nvidia.com/v1"

class NvidiaClient:
    def __init__(self, api_key, model="meta/llama-3.3-70b-instruct"):
        self.api_key = api_key
        self.model = model

    def chat_completion(self, messages, max_tokens=4096, temperature=0.2):
        if not self.api_key:
            logger.warning("NVIDIA API key not configured")
            return None

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": 0.7,
        }

        from utils.rate_limiter import rate_limiter
        from utils.stealth import stealth
        from core.database import db

        rate_limiter.wait("nvidia")
        stealth.random_delay(1, 2)

        start = time.time()
        try:
            resp = requests.post(
                f"{NVIDIA_BASE}/chat/completions",
                headers=headers,
                json=data,
                timeout=120,
            )
            duration_ms = int((time.time() - start) * 1000)
            db.record_api_call("nvidia", NVIDIA_BASE, resp.status_code, duration_ms)

            if resp.status_code == 200:
                result = resp.json()
                content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
                tokens = result.get("usage", {}).get("total_tokens", 0)
                logger.info(f"NVIDIA OK - {tokens} tokens")
                return content
            elif resp.status_code == 429:
                logger.warning("NVIDIA rate limited")
                time.sleep(30)
            else:
                logger.warning(f"NVIDIA HTTP {resp.status_code}: {resp.text[:200]}")

        except requests.exceptions.Timeout:
            logger.warning("NVIDIA request timed out")
        except requests.exceptions.RequestException as e:
            logger.warning(f"NVIDIA request failed: {e}")

        return None

    def test_connection(self):
        if not self.api_key:
            return False, "No API key configured"
        try:
            resp = requests.get(
                f"{NVIDIA_BASE}/models",
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10,
            )
            if resp.status_code == 200:
                models = resp.json().get("data", [])
                return True, f"OK ({len(models)} models available)"
            return False, f"HTTP {resp.status_code}"
        except Exception as e:
            return False, str(e)

    def list_free_models(self):
        try:
            resp = requests.get(
                f"{NVIDIA_BASE}/models",
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10,
            )
            if resp.status_code == 200:
                models = resp.json().get("data", [])
                chat_models = [m["id"] for m in models if "chat" in m.get("id", "").lower()]
                return chat_models[:20]
        except Exception:
            pass
        return []
