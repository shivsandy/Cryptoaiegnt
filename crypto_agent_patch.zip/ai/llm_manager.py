import logging
import json
import re

logger = logging.getLogger(__name__)

_openrouter_client = None
_nvidia_client = None

def configure(openrouter_keys, nvidia_key, site_url="", site_name=""):
    global _openrouter_client, _nvidia_client
    from ai.openrouter_client import OpenRouterClient
    from ai.nvidia_client import NvidiaClient
    _openrouter_client = OpenRouterClient(openrouter_keys, site_url, site_name)
    _nvidia_client = NvidiaClient(nvidia_key)

def analyze_with_fallback(source_code, contract_name):
    from ai.prompts import ANALYSIS_SYSTEM_PROMPT, build_analysis_prompt

    if not _openrouter_client and not _nvidia_client:
        logger.error("No LLM clients configured")
        return None

    system_msg = {"role": "system", "content": ANALYSIS_SYSTEM_PROMPT}
    user_msg = {
        "role": "user",
        "content": [{"type": "text", "text": build_analysis_prompt(source_code, contract_name)}]
    }
    messages = [system_msg, user_msg]

    models_to_try = [
        ("openrouter", "openrouter/free"),
        ("openrouter", "deepseek/deepseek-chat:free"),
        ("openrouter", "qwen/qwen-2.5-coder-32b-instruct:free"),
        ("nvidia", None),
        ("openrouter", "google/gemini-2.0-flash:free"),
    ]

    for provider, model in models_to_try:
        try:
            if provider == "openrouter" and _openrouter_client:
                logger.info(f"Trying OpenRouter model: {model}")
                content = _openrouter_client.chat_completion(messages, model=model)
            elif provider == "nvidia" and _nvidia_client:
                logger.info("Trying NVIDIA model")
                content = _nvidia_client.chat_completion(messages)
            else:
                continue

            if content:
                parsed = _parse_ai_response(content)
                if parsed:
                    logger.info(f"AI analysis parsed successfully from {provider}")
                    return parsed
                else:
                    logger.warning(f"Failed to parse AI response from {provider}")
        except Exception as e:
            logger.warning(f"{provider} failed: {e}")
            continue

    logger.error("All AI providers exhausted")
    return None

def _parse_ai_response(content):
    json_match = re.search(r'\{[\s\S]*"findings"[\s\S]*\}', content)
    if json_match:
        try:
            parsed = json.loads(json_match.group())
            if "findings" in parsed and isinstance(parsed["findings"], list):
                return parsed
        except json.JSONDecodeError:
            pass
    json_match = re.search(r'\{[\s\S]*"overall_severity"[\s\S]*\}', content)
    if json_match:
        try:
            return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
    return {
        "overall_severity": "medium",
        "risk_score": 5,
        "summary": "AI analysis completed but response format was non-standard. Review the raw analysis.",
        "findings": [{"title": "Review Required", "severity": "medium", "description": content[:1000]}],
    }

def generate_submission_body(report_data):
    from ai.prompts import SUBMISSION_SYSTEM_PROMPT

    if not _openrouter_client:
        return _fallback_submission_body(report_data)

    messages = [
        {"role": "system", "content": SUBMISSION_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": [{"type": "text", "text": f"Generate a professional bug bounty submission report for:\n\nTitle: {report_data.get('title', 'Security Vulnerability')}\nDescription: {report_data.get('description', '')}\nImpact: {report_data.get('impact', '')}\nSeverity: {report_data.get('severity', 'medium')}\n\nWrite the complete report body ready for submission."}]
        },
    ]

    content = _openrouter_client.chat_completion(messages, model="openrouter/free", max_tokens=2048, temperature=0.3)
    if content:
        content = re.sub(r'[\U0001F300-\U0001FAFF]', '', content)
        content = re.sub(r'[\u2600-\u27BF]', '', content)
        return content.strip()

    return _fallback_submission_body(report_data)

def _fallback_submission_body(report_data):
    body = f"""Vulnerability Report: {report_data.get('title', 'Security Vulnerability')}

Description:
{report_data.get('description', 'No description provided.')}

Impact:
{report_data.get('impact', 'No impact assessment provided.')}

Severity: {report_data.get('severity', 'medium').upper()}

Recommendation:
{report_data.get('recommendation', 'No recommendation provided.')}

Proof of Concept:
{report_data.get('proof_of_concept', 'No PoC provided.')}

Contract: {report_data.get('contract_address', 'N/A')}"""
    return body
