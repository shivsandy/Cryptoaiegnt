import logging
import requests
import json
import time
import threading

logger = logging.getLogger(__name__)

OPENROUTER_BASE = "https://openrouter.ai/api/v1"

class OpenRouterClient:
    def __init__(self, api_keys, site_url="", site_name=""):
        self.api_keys = api_keys
        self.site_url = site_url
        self.site_name = site_name
        self._key_index = 0
        self._lock = threading.Lock()
        self._key_blacklist = {}
        self._usage_counts = {i: 0 for i in range(len(api_keys))}

    def _get_next_key(self):
        with self._lock:
            if not self.api_keys:
                return None, -1
            attempts = 0
            while attempts < len(self.api_keys):
                idx = self._key_index % len(self.api_keys)
                self._key_index += 1
                if idx not in self._key_blacklist or time.time() > self._key_blacklist[idx]:
                    self._usage_counts[idx] = self._usage_counts.get(idx, 0) + 1
                    return self.api_keys[idx], idx
                attempts += 1
            return None, -1

    def _blacklist_key(self, idx, duration=300):
        with self._lock:
            self._key_blacklist[idx] = time.time() + duration
            logger.warning(f"OpenRouter key {idx+1} blacklisted until {time.strftime('%H:%M:%S', time.localtime(time.time() + duration))}")

    def chat_completion(self, messages, model="openrouter/free", max_tokens=4096, temperature=0.1):
        for attempt in range(3):
            api_key, key_idx = self._get_next_key()
            if not api_key:
                logger.error("No valid OpenRouter keys available")
                return None

            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }
            if self.site_url:
                headers["HTTP-Referer"] = self.site_url
            if self.site_name:
                headers["X-OpenRouter-Title"] = self.site_name

            data = {
                "model": model,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
            }

            from utils.rate_limiter import rate_limiter
            from utils.stealth import stealth
            from core.database import db

            rate_limiter.wait("openrouter")
            stealth.random_delay(1, 3)

            start = time.time()
            try:
                resp = requests.post(
                    f"{OPENROUTER_BASE}/chat/completions",
                    headers=headers,
                    json=data,
                    timeout=120,
                )
                duration_ms = int((time.time() - start) * 1000)
                db.record_api_call(f"openrouter_key_{key_idx+1}", OPENROUTER_BASE, resp.status_code, duration_ms)

                if resp.status_code == 200:
                    result = resp.json()
                    content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
                    logger.info(f"OpenRouter key {key_idx+1} OK - {result.get('usage', {}).get('total_tokens', 0)} tokens")
                    return content
                elif resp.status_code == 429:
                    logger.warning(f"OpenRouter key {key_idx+1} rate limited")
                    self._blacklist_key(key_idx, 120)
                elif resp.status_code == 402:
                    logger.warning(f"OpenRouter key {key_idx+1} insufficient credits")
                    self._blacklist_key(key_idx, 3600)
                elif resp.status_code == 401:
                    logger.warning(f"OpenRouter key {key_idx+1} unauthorized")
                    self._blacklist_key(key_idx, 86400)
                else:
                    logger.warning(f"OpenRouter key {key_idx+1} HTTP {resp.status_code}")
                    self._blacklist_key(key_idx, 60)

            except requests.exceptions.Timeout:
                logger.warning(f"OpenRouter key {key_idx+1} timeout")
                self._blacklist_key(key_idx, 60)
            except requests.exceptions.RequestException as e:
                logger.warning(f"OpenRouter key {key_idx+1} error: {e}")
                self._blacklist_key(key_idx, 30)

        logger.error("All OpenRouter keys exhausted")
        return None

    def test_connection(self, key_index=0):
        if key_index >= len(self.api_keys):
            return False, "No key configured"
        try:
            resp = requests.get(
                f"{OPENROUTER_BASE}/key",
                headers={"Authorization": f"Bearer {self.api_keys[key_index]}"},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json().get("data", {})
                remaining = data.get("limit_remaining", "unknown")
                return True, f"OK ({remaining} credits remaining)"
            return False, f"HTTP {resp.status_code}"
        except Exception as e:
            return False, str(e)
