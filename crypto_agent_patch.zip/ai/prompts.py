ANALYSIS_SYSTEM_PROMPT = """You are an expert blockchain security auditor specializing in Solidity smart contract analysis. Analyze the provided smart contract code for security vulnerabilities, logic errors, and best practice violations.

For each vulnerability found, provide:
1. Title: Clear, descriptive name of the vulnerability
2. Severity: critical, high, medium, or low
3. Description: Detailed explanation of the vulnerability
4. Impact: What an attacker could achieve
5. Location: Function name and line number where the issue exists
6. Recommendation: How to fix the vulnerability
7. Code snippet: The vulnerable code section

Consider these vulnerability categories:
- Reentrancy attacks
- Access control issues
- Integer overflow/underflow
- Oracle manipulation
- Flash loan attacks
- Front-running
- Signature replay
- Logic errors
- Gas optimization issues
- Centralization risks
- Unchecked external calls
- Price manipulation

At the end, provide:
- Overall severity assessment for the contract
- Summary of findings
- Risk score (1-10)

Respond in valid JSON format only, no markdown wrapping."""

SUBMISSION_SYSTEM_PROMPT = """Act as a professional security researcher bug hunter and write the email and submit without any emoji to the platforms. Write a formal, professional vulnerability report suitable for submission to a bug bounty platform.

The report should include:
1. Title: Vulnerability classification and impact
2. Description: Clear technical explanation
3. Impact assessment: Funds at risk, attack scenario
4. Severity: Based on CVSS-like scoring
5. Recommendation: How to fix
6. Proof of Concept: Runnable exploit code or detailed steps

Use professional language, be precise, and avoid markdown formatting in the final text. Keep the tone of a professional security researcher submitting a finding."""

def build_analysis_prompt(source_code, contract_name):
    return f"""Analyze the following Solidity smart contract for security vulnerabilities:

Contract Name: {contract_name}

```solidity
{source_code[:8000]}
```

Provide a complete security analysis including all vulnerabilities found, their severity, impact, and recommended fixes. Respond in JSON format with the following structure:
{{
  "overall_severity": "critical|high|medium|low",
  "risk_score": <1-10>,
  "summary": "brief summary",
  "findings": [
    {{
      "title": "vulnerability name",
      "severity": "critical|high|medium|low",
      "description": "detailed description",
      "impact": "what attacker can do",
      "location": "function/line",
      "recommendation": "how to fix",
      "code_snippet": "vulnerable code"
    }}
  ]
}}"""

def build_submission_body(report_data):
    title = report_data.get("title", "Security Vulnerability Report")
    description = report_data.get("description", "")
    impact = report_data.get("impact", "")
    severity = report_data.get("severity", "medium")
    poc = report_data.get("proof_of_concept", "")
    recommendation = report_data.get("recommendation", "")

    body = f"""Vulnerability Report: {title}

Description:
{description}

Impact:
{impact}

Severity: {severity.upper()}

Proof of Concept:
{poc}

Recommendation:
{recommendation}

References:
- Contract: {report_data.get('contract_address', 'N/A')}
- Chain: Ethereum Mainnet
"""

    return body
