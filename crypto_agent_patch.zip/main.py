#!/usr/bin/env python3
import logging
import os
import sys
import signal
import asyncio

from config import Config
from utils.logger import setup_logger

logger = logging.getLogger(__name__)

_application = None

def signal_handler(sig, frame):
    logger.info("Shutting down...")
    from core.database import db
    from core.scheduler import scheduler
    scheduler.stop()
    db.close()
    if _application:
        try:
            _application.stop(run_async=True)
        except Exception:
            pass
    logger.info("Shutdown complete")
    sys.exit(0)

def main():
    global _application

    setup_logger()
    logger.info("Starting Crypto Security AI Bug Bounty Hunter...")

    cfg = Config()
    if not cfg.is_valid():
        logger.error("Configuration invalid. Run install.sh or check api.txt.")
        sys.exit(1)

    from core.database import db
    mongo_uri = cfg.get("MONGODB_URI", "")
    mongo_db = cfg.get("MONGODB_DB_NAME", "bug_bounty_hunter")
    if mongo_uri:
        if not db.connect(mongo_uri, mongo_db):
            logger.warning("MongoDB connection failed. Check MONGODB_URI in api.txt and ensure pymongo[srv] is installed. Verify cluster name and IP whitelist in MongoDB Atlas.")
    else:
        logger.warning("MongoDB URI not configured in api.txt")

    from scanner.etherscan import configure as configure_etherscan
    configure_etherscan(
        api_key=cfg.get("ETHERSCAN_API_KEY", ""),
        chain_id=int(cfg.get("DEFAULT_CHAIN_ID", "1")),
    )

    from ai.llm_manager import configure as configure_llm
    configure_llm(
        openrouter_keys=cfg.get_openrouter_keys(),
        nvidia_key=cfg.get("NVIDIA_API_KEY", ""),
        site_url=cfg.get("OPENROUTER_SITE_URL", ""),
        site_name=cfg.get("OPENROUTER_SITE_NAME", ""),
    )

    from submitter.hackerone import configure as configure_hackerone
    h1_creds = cfg.get_hackerone_creds()
    if h1_creds:
        configure_hackerone(h1_creds["username"], h1_creds["token"])
        logger.info("HackerOne credentials loaded from api.txt")
    else:
        logger.info("HackerOne credentials not configured in api.txt")

    from submitter.immunefi import configure as configure_immunefi
    imm_creds = cfg.get_immunefi_creds()
    if imm_creds:
        configure_immunefi(imm_creds["email"], imm_creds["password"], imm_creds.get("2fa", ""))
        logger.info("Immunefi credentials loaded from api.txt")
    else:
        logger.info("Immunefi credentials not configured in api.txt")

    from utils.rate_limiter import rate_limiter
    rate_limiter.register("etherscan", 5, burst=5)
    rate_limiter.register("openrouter", 20, burst=20)
    rate_limiter.register("nvidia", 20, burst=20)
    rate_limiter.register("hackerone", 10, burst=10)

    from telegram.bot import create_bot, register_handlers
    from telegram.handlers import (
        start_command, help_command, info_command, testapi_command,
        approvals_command, rejected_command, balance_command,
        scan_command, clearcache_command, callback_handler,
    )
    from telegram.handlers import configure as configure_handlers
    import telegram.notifier as notifier

    token = cfg.get("TELEGRAM_BOT_TOKEN", "")
    owner = cfg.get("TELEGRAM_BOT_OWNER", "imTerabyte")
    chat_id = cfg.get("TELEGRAM_CHAT_ID", "")

    if not token:
        logger.error("Telegram bot token not configured")
        sys.exit(1)

    _application = create_bot(token)
    configure_handlers({
        "TELEGRAM_BOT_OWNER": owner,
        "TELEGRAM_CHAT_ID": chat_id,
    })
    notifier.configure(_application, chat_id, owner)

    handlers = {
        "commands": {
            "start": start_command,
            "help": help_command,
            "info": info_command,
            "testapi": testapi_command,
            "approvals": approvals_command,
            "rejected": rejected_command,
            "balance": balance_command,
            "scan": scan_command,
            "clearcache": clearcache_command,
        },
        "callback": callback_handler,
    }
    register_handlers(_application, handlers)

    from core.scheduler import scheduler
    def auto_scan_job():
        from core.database import db
        item = db.get_next_watchlist_item()
        if item:
            from core.pipeline import pipeline
            logger.info(f"Auto-scan triggered for {item['address']}")
            pipeline.execute(item["address"])
    scheduler.start(scan_callback=auto_scan_job, interval_hours=6)

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    logger.info("Bot started. Press Ctrl+C to stop.")
    start_polling(_application)

def start_polling(app):
    try:
        logger.info("Starting Telegram polling...")
    except Exception as e:
        logger.error(f"Bot startup failed: {e}")
        return
    app.run_polling(allowed_updates=["message","callback_query"])

if __name__ == "__main__":
    main()
