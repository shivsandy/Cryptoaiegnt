#!/bin/bash
cd "$(dirname "$0")"
source venv/bin/activate
python main.py >> logs/cron.log 2>&1
